#include <hidef.h>      
#include "mc9s12xep100.h"
#include "xgate.h"


#include <string.h>
#include "xgate.h"
#include "stdio.h"


#define XGSWT0M 0x0100
#define XGSWT1M 0x0200
#define XGSWT2M 0x0400
#define XGSWT3M 0x0800
#define XGSWT4M 0x1000
#define XGSWT5M 0x2000
#define XGSWT6M 0x4000
#define XGSWT7M 0x8000

#define XGSWT0 0x01
#define XGSWT1 0x02
#define XGSWT2 0x04
#define XGSWT3 0x08
#define XGSWT4 0x10
#define XGSWT5 0x20
#define XGSWT6 0x40
#define XGSWT7 0x80

/************************* Macros ******************************************/
#define ROUTE_INTERRUPT(vec_adr, cfdata)                \
  INT_CFADDR= (vec_adr) & 0xF0;                         \
  INT_CFDATA_ARR[((vec_adr) & 0x0F) >> 1]= (cfdata)

#define SCI0_VEC  0xD6 /* vector address= $xxD6 */


//Initialise the XGATE
static void SetupXGATE(void)
{
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* switch SCI0 interrupt to XGATE */
  ROUTE_INTERRUPT(SCI0_VEC, 0x81); /* RQST=1 and PRIO=1 */

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xFBC1; /* XGE | XGFRZ | XGIE */
}



void InitSCI0(void) 
{
    SCI0BD = 13;       // baudrate = 9600: baudrate = busfreq/sci0bd/16 
  
    SCI0CR2_TE = 1;    // Enable transmitter
    SCI0CR2_RE = 1;    // Enable receiver

    SCI0CR2_RIE = 1;   // Enable the SCI Rx interrupt
}


void TERMIO_PutChar(char C) 
{
    while(!SCI0SR1_TDRE);
    SCI0DRL=C;
}


void main(void)
{

    //SetupXGATE();

    InitSCI0();

    EnableInterrupts;    

    printf("\n\r\n\r S12XE ISR / XGATE Thread .\n\r");          
    for(;;) {
    } 
}


#pragma CODE_SEG __NEAR_SEG NON_BANKED 
interrupt void SCI_Handler() 
{
    SCI0SR1;        // read the status register - required to clear the int flag 
    SCI0DRL=SCI0DRL;

    while(!SCI0SR1_TDRE);
    SCI0DRL='_';
}



