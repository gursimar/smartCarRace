#define SYS_PARAM_DFLASH_START  0x100000
#define SIZEOF_SYSTEM_DATA      (int)__SEG_SIZE_REF(SYSTEM_DATA)  
#define SYSTEM_DATA_START       __SEG_START_REF(SYSTEM_DATA); // start of system parameter variables


#pragma DATA_SEG SYSTEM_DATA    /* linked into the buffer RAM at 0x0C00 */

extern int  PARAM_1;            
extern int  PARAM_2;            
extern char PARAM_3;            
extern int  PARAM_4;            
extern int  PARAM_5;            
extern tU16 PARAM_6;            
extern tU16 PARAM_7;
extern tU16 PARAM_8;
extern char PARAM_9;
extern tU16 PARAM_10;
extern tU16 PARAM_11;
extern tU16 PARAM_12;
extern tU16 PARAM_13;
extern tU08 PARAM_14;    
extern tU16 PARAM_15;    

void InitSysParams(void);      
