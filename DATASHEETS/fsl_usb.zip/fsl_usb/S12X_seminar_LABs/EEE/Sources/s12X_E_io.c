/******************************************************************************
		                                             COPYRIGHT (c) Freescale 2006   
FILE NAME: S12X_E_IO.C                                                      
                                                                          
PURPOSE: S12X D family i/o configuration      											 
                                                                          
TARGET DEVICE: S12XEP100                                               
                                                                          
INCLUDE FILES: s12_io.h, target.h                                               
                                                                          
FUNCTIONS :  ConfigurePorts                                                    
                                                   
Tasks	 :  none                                                  			 
Hooks   :	 none                                                            
ISRs	 :	 none                                                                
                                                                         
COMPILER: Metrowerks                     
                                                                          
DESCRIPTION: Routine to configure S12XEP100                                             
                                                                          
NOTES
-----
E-clk can be monitored on jumper PE4.
                                                                          
UPDATE HISTORY                                                            
REV      AUTHOR      DATE         DESCRIPTION OF CHANGE                    
---      ------      ---------    ---------------------                   
1.0      r32151      13/10/05     Initial coding 
1.1      r32151      26/01/06     ATD ports corrected
                                                                           

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

/************************* Include Files *************************************/
#include "s12x_peripherals.h"
#include "target.h"  /* includes device peripheral declarations */
#include "S12_io.h"


/************************* typedefs ******************************************/
/* in s12x_vectors.h */
/************************* function prototypes *******************************/
/* in s12x_vectors.h */
//#define ECLK_OUT					/* uncomment for Debug */
/************************* #defines ******************************************/
/* in s12x_vectors.h */
/************************* Constants *****************************************/
#pragma CONST_SEG DEFAULT
/************************* Global Variables **********************************/
#pragma DATA_SEG DEFAULT
/************************* Functions *****************************************/
#pragma CODE_SEG DEFAULT 

/******************************************************************************
Function Name	:	ConfigurePorts
Engineer		   :	r32151
Date			   :	01/03/05
Headers			: 	s12_io.h, target.h
Parameters		:	NONE
Returns			:	NONE
Notes			   :	Code to set up i/o ports 
******************************************************************************/
void
ConfigurePorts(void)
{

/******* CORE PORTS ********/

/* core interrupts */
/* This register register was renamed. On early D, A and H families it is called INTCR,
   on all other families it is called IRQCR. */
	IRQCR.byte = 0;		/* IRQ only responds to falling edge  */
								/*	- note IRQE is write once */								

/*include this line to clear the X-bit in order to enable the XIRQ function */   
//  asm ANDCC #~BIT6;	

/* drive level */
	RDRIV.byte = ALL_REDUCED_DRIVE;						/* core ports reduced drive */
/* Enable Pull devices */
	PUCR.byte 	= ALL_PULLS_ON; 							/* Note: only pull-ups available on core ports */
						  						/* some port E pins require care when using external pull devices*/
						  						/* port E.7: pull up for LC Pierce, tie low for ext osc or full Pierce, */
						  						/*           reset enables internal pull up.                     */
						  						/* port E.5 & E.6 should be pulled down for single chip use      */
						  						/*           reset enables internal pull down.                   */
/* configure port data and direction */
/* PORT A */
	PORTA.byte = ALL_LOW;	   
	DDRA.byte = ALL_INPUTS;
/* PORT B */
	PORTB.byte = ALL_HIGH;	   					
	DDRB.byte = ALL_OUTPUTS; 					    
/* PORT C */
	PORTC.byte = ALL_LOW;	   
	DDRC.byte = ALL_INPUTS;
/* PORT D */
	PORTD.byte = ALL_LOW;	   					
	DDRD.byte = ALL_INPUTS; 					    
/* PORT E */
	PORTE.byte = ALL_LOW;	   
	DDRE.byte = ALL_INPUTS; 		
/* PORT K */
	PORTK.byte = ALL_LOW;	   
	DDRK.byte = ALL_INPUTS;
	
/******* PIM PORTS ********/

/* PORT T */
/* Configure Pull-polarity */
	PPST.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERT.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRT.byte 	= ALL_REDUCED_DRIVE;
/* port data */
	PTT.byte 	= ALL_LOW;   
/* port direction */
	DDRT.byte 	= ALL_INPUTS;

/* PORT S */
/* Configure Pull-polarity */
	PPSS.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */

/* Enable Pull devices */
	PERS.byte 	= ALL_PULLS_ON;					
//	PERS.byte 	= BIT7|BIT6|BIT5|BIT4;					/* S12 EVB - no pull devices on port S0-3 due to avoid */ 
																	/* conflict with connections to RS232 transceiver */
/* drive level */
	RDRS.byte 	= ALL_REDUCED_DRIVE;
/* Configure wired-or outputs */
	WOMS.byte 	= 0x00;
/* port data */
	PTS.byte 	= ALL_LOW;	   
/* port direction */
	DDRS.byte 	= ALL_INPUTS;
	
/* PORT M */
/* Configure Pull-polarity */
	PPSM.byte = ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERM.byte 	= ALL_PULLS_ON; 	
//	PERM.byte 	= BIT7|BIT6|BIT5|BIT4|BIT3|BIT2|BIT1; 	/* S12 EVB - no pull device enebled on port M0 as it's */
																  	   /*driven by the CAN transceiver Rx pin */
/* drive level */
	RDRM.byte 	= ALL_REDUCED_DRIVE;
/* Configure wired-or outputs */
	WOMM.byte 	= 0x00;	   
/* port data */
	PTM.byte 	= ALL_LOW;	   
/* port direction */
	DDRM.byte 	= ALL_INPUTS;
	
/* PORT P */
/* Configure Pull-polarity */
	PPSP.byte 	= ALL_PULLED_UP;
/* Enable Pull devices */
	PERP.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRP.byte 	= ALL_REDUCED_DRIVE;						
/* port data */
	PTP.byte 	= ALL_LOW;		   
/* port direction */
	DDRP.byte 	= ALL_INPUTS;     
/* Clear all interrupt flags */
	PIFP.byte 	= 0xFF;
/* Enable interrupts */
	PIEP.byte 	= 0x00;
	
/* PORT H */
/* Configure Pull-polarity */
	PPSH.byte 	= ALL_PULLED_UP;	/* EVB - PortH should always pulled up */
/* Enable Pull devices */
	PERH.byte 	= ALL_PULLS_ON;								
/* drive level */
	RDRH.byte 	= ALL_REDUCED_DRIVE;
/* port data */
	PTH.byte 	= ALL_LOW;	   
/* port direction */
	DDRH.byte 	= ALL_INPUTS;
//	DDRH.byte 	= 0x0F;           /* S12X EVB, LEDs on lower nibble, switches on upper - pull up */
/* Clear all interrupt flags */
	PIFH.byte 	= 0xFF;
/* Enable interrupts */
	PIEH.byte 	= 0x00;

/* PORT J */
/* Configure Pull-polarity */
	PPSJ.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERJ.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRJ.byte 	= ALL_REDUCED_DRIVE;
/* port data */
	PTJ.byte 	= ALL_LOW;	   
/* port direction */
	DDRJ.byte 	= ALL_INPUTS;
/* Clear all interrupt flags */
	PIFJ.byte 	= 0xFF;
/* Enable interrupts */
	PIEJ.byte 	= 0x00;
	
/* PORT R */
/* Configure Pull-polarity */
	PPSR.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERR.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRR.byte 	= ALL_REDUCED_DRIVE;
/* port data */
	PTR.byte 	= ALL_LOW;	   
/* port direction */
	DDRR.byte 	= ALL_INPUTS;

/* PORT L */
/* Configure Pull-polarity */
	PPSL.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERL.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRL.byte 	= ALL_REDUCED_DRIVE;
/* Configure wired-or outputs */
	WOML.byte 	= 0x00;	   
/* port data */
	PTL.byte 	= ALL_LOW;	   
/* port direction */
	DDRL.byte 	= ALL_INPUTS;

/* PORT F */
/* Configure Pull-polarity */
	PPSF.byte 	= ALL_PULLED_DOWN;
/* Enable Pull devices */
	PERF.byte 	= ALL_PULLS_ON;
/* drive level */
	RDRF.byte 	= ALL_REDUCED_DRIVE;
/* port data */
	PTF.byte 	= ALL_LOW;	   
/* port direction */
	DDRF.byte 	= ALL_INPUTS;


/******* ATD PORTS ********/
/* In order to use the digital input function the ATDIEN bit needs to be set */
/* ! NOTE: ATD port pull-ups are active for both digital and analog inputs ! */
/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/	

/*for PAD[7:0] */	
   PER1AD0.byte 	= ALL_PULLS_OFF;     /* Port AD0 Pull-up Enable */
	ATD0.atddien1.byte = 0x00;				/* 1 = digital input enabled */
   RDR1AD0.byte 	= ALL_REDUCED_DRIVE; /* Port AD0 Reduced Drive Register 1 */
   PT1AD0.byte 	= ALL_LOW;	         /* Port AD0 I/O Register 1 */
   DDR1AD0.byte 	= ALL_INPUTS;        /* Port AD0 Data Direction Register 1 */

/*for PAD[15:8] */  
   PER0AD0.byte 	= ALL_PULLS_OFF;     /* Port AD1 Pull-up Enable */
	ATD0.atddien0.byte = 0x00;				/* 1 = digital input enabled */
   RDR0AD0.byte 	= ALL_REDUCED_DRIVE; /* Port AD1 Reduced Drive Register 1 */
   PT0AD0.byte 	= ALL_LOW;	         /* Port AD1-1 I/O Register 1 */
   DDR0AD0.byte 	= ALL_INPUTS;        /* Port AD1 Data Direction Register 0 */

/*for PAD[23:16] */   
   PER1AD1.byte 	= ALL_PULLS_OFF;     /* Port AD1 Pull-up Enable */
	ATD1.atddien1.byte = 0x00;				/* 1 = digital input enabled */
   RDR1AD1.byte 	= ALL_REDUCED_DRIVE; /* Port AD1 Reduced Drive Register 1 */
   PT1AD1.byte 	= ALL_LOW;	         /* Port AD1-1 I/O Register 1 */
   DDR1AD1.byte 	= ALL_INPUTS;        /* Port AD1 Data Direction Register 0 */

/*for PAD[31:24] */  
   PER0AD1.byte 	= ALL_PULLS_OFF;     /* Port AD1 Pull-up Enable */
	ATD1.atddien0.byte = 0x00;				/* 1 = digital input enabled */
   RDR0AD1.byte 	= ALL_REDUCED_DRIVE; /* Port AD1 Reduced Drive Register 0 */
   PT0AD1.byte 	= ALL_LOW;	         /* Port AD1-0 I/O Register 0 */
   DDR0AD1.byte 	= ALL_INPUTS;        /* Port AD1 Data Direction Register 0 */


/***** module routing *****/

/* Module Routing Register */
	MODRR.byte = 0;   
      /* XE-family	----------------- 
            										  Rx  Tx
            modrr[0:1]	CAN0 routing 0:0 => PM0:PM1 
                                     0:1 => PM2:PM3  
                                     1:0 => PM4:PM5  
                                     1:1 => PJ6:PJ7 

            										  Rx  Tx
			   modrr[3:2]	CAN4 routing 0:0 => PJ6:PJ7 
                                     0:1 => PM4:PM5  
                                     1:0 => PM6:PM7  
                                     1:1 => reserved   

														MISO:MOSI:SCK :SS
			   modrr[4]		SPI0 routing 0 => PS4: PS5: PS6 :PS7
			    								 1 => PM2: PM4: PM5 :PM3

														MISO:MOSI:SCK :SS
			   modrr[5]		SPI1 routing 0 => PP0: PP1: PP2 :PP3
			    								 1 => PH0: PH1: PH2 :PH3
 
														MISO:MOSI:SCK :SS
		      modrr[6]		SPI2 routing 0 => PP4: PP5: PP7 :PP6
			    								 1 => PH4: PH5: PH6 :PH7
            
            modrr[7]		reserved                   */
 

/* PORT L Module Routing Register */ 
   PTLRR.byte = 0;    
      /* XE-family	----------------- 
            										Tx :Rx
			   ptlrr[4]		SCI4 routing 0 => PH5:PH4 
                                     1 => PL1:PL0 
 
            										Tx :Rx
			   ptlrr[5]		SCI5 routing 0 => PH7:PH6 
                                     1 => PL3:PL2 

            										Tx :Rx
			   ptlrr[6]		SCI6 routing 0 => PH1:PH0 
                                     1 => PL5:PL4 

            										Tx :Rx
			   ptlrr[7]		SCI7 routing 0 => PH3:PH2 
                                     1 => PL7:PL6 
          
            ptlrr[0:3]		reserved                */

/* PORT F Module Routing Register */
   PTFRR.byte = 0;    
      /* XE-family	----------------- 
            										  
            ptfrr[0]	   CS0 routing 0 => PJ4 
                                    1 => PF0 

            ptfrr[1]	   CS1 routing 0 => PJ2 
                                    1 => PF1 

            ptfrr[2]	   CS2 routing 0 => PJ5 
                                    1 => PF2 

            ptfrr[3]	   CS3 routing 0 => PJ0 
                                    1 => PF3 

            										SCL:SDA
			   ptfrr[4]		IIC0 routing 0 => PJ7:PJ6 
                                     1 => PF5:PF4 

            										Tx :Rx
			   ptfrr[5]		SCI3 routing 0 => PM7:PM6 
                                     1 => PF7:PF6 
 
          
            ptfrr[7:6]		reserved                */


/* PORT R Module Routing Register */
   PTRRR.byte = 0;    
      /* XE-family	----------------- 
            										  
            ptrrr[0]	   TIM CH0 routing 0 => PR0 
                                        1 => PP0 

            ptrrr[1]	   TIM CH1 routing 0 => PR1 
                                        1 => PP1 
 
            ptrrr[2]	   TIM CH2 routing 0 => PR2 
                                        1 => PP2 
 
            ptrrr[3]	   TIM CH3 routing 0 => PR3 
                                        1 => PP3 
 
            ptrrr[4]	   TIM CH4 routing 0 => PR4 
                                        1 => PP4 
 
            ptrrr[5]	   TIM CH5 routing 0 => PR5 
                                        1 => PP5 
 
            ptrrr[6]	   TIM CH6 routing 0 => PR6 
                                        1 => PP6 
 
            ptrrr[7]	   TIM CH7 routing 0 => PR7 
                                        1 => PP7   */
 
 
 
 /***** ECKL options *****/
 
/* ECLK available on PortE.4, ECLKx2 available on Port E.7 
    - note, keeping port E configured for reduced drive 
		 will minimise ECLK generated noise */							
#ifdef ECLK_OUT
// ECLKDIV = 1 to 32; DEFINED IN TARGET.H 
/* select one: */
   ECLKCTL.byte = NCLKX2|NECLK;              /* ECLKx2 off. ECLK              off */
//   ECLKCTL.byte = NECLK ;                    /* ECLKx2 on.  ECLK              off */
//   ECLKCTL.byte = NCLKX2|(ECLKDIV-1);        /* ECLKx2 off. ECLK/ECLKDIV       on */
//   ECLKCTL.byte = NCLKX2|(ECLKDIV-1)|DIV16;  /* ECLKx2 off. ECLK/(ECLKDIV*16)  on */
//   ECLKCTL.byte = (ECLKDIV-1);               /* ECLKx2 on.  ECLK/(ECLKDIV)     on */
//   ECLKCTL.byte = (ECLKDIV-1)|DIV16;         /* ECLKx2 on.  ECLK/(ECLKDIV*16)  on */


#endif
}
