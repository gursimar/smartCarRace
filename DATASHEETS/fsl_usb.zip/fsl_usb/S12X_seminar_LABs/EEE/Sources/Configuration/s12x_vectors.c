/******************************************************************************
													            Copyright (c) Freescale 2006
File Name    : $RCSfile: s12x_vectors.c,v $

Engineer     : $Author: r32151 $

Location     : EKB

Description  : Parameterised CPU Vector table definition for MC9S12XEP100.
               ISR references are defined in interrupts.h.

Current Revision :	$Revision: 1.7 $

Notes            :  

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

/************************* Include Files *************************************/
#include <hidef.h>
#include <start12.h>
#include "s12x_peripherals.h"
#include "target.h"
#include "s12x_vectors.h"
#include "interrupts.h"

/************************* typedefs ******************************************/
/* in s12x_vectors.h */
/************************* function prototypes *******************************/
//#pragma CODE_SEG __NEAR_SEG NON_BANKED 

//#define TEST_HERE
#include <non_bank.sgm>		 /* sets code seg to non banked near if not small */
//#undef TEST_HERE

interrupt void _S12_VEC_10(void);     /* 0xFF10 Spurious Interrupt */
interrupt void _S12_VEC_12(void);     /* 0xFF12 SYS - System interrupt */
interrupt void _S12_VEC_14(void);     /* 0xFF14 MPU Access error */
interrupt void _S12_VEC_16(void);     /* 0xFF16 XGATE error */
interrupt void _S12_VEC_3C(void);     /* 0xFF3C ATD1 compare */                            
interrupt void _S12_VEC_3E(void);     /* 0xFF3E ATD0 compare */                            
interrupt void _S12_VEC_40(void);     /* 0xFF40 TIM Pulse accumulator input edge */     
interrupt void _S12_VEC_42(void);     /* 0xFF42 TIM Pulse accumulator A overflow */     
interrupt void _S12_VEC_44(void);     /* 0xFF44 TIM overflow */  
interrupt void _S12_VEC_46(void);     /* 0xFF46 TIM channel 7 */                                 
interrupt void _S12_VEC_48(void);     /* 0xFF48 TIM channel 6 */ 
interrupt void _S12_VEC_4A(void);     /* 0xFF4A TIM channel 5 */ 
interrupt void _S12_VEC_4C(void);     /* 0xFF4C TIM channel 4 */ 
interrupt void _S12_VEC_4E(void);     /* 0xFF4E TIM channel 3 */ 
interrupt void _S12_VEC_50(void);     /* 0xFF50 TIM channel 2 */ 
interrupt void _S12_VEC_52(void);     /* 0xFF52 TIM channel 1 */ 
interrupt void _S12_VEC_54(void);     /* 0xFF54 TIM channel 0 */ 
interrupt void _S12_VEC_56(void);     /* 0xFF56 SCI7 */                     
interrupt void _S12_VEC_58(void);     /* 0xFF58 Periodic Interrupt Timer 7 */          
interrupt void _S12_VEC_5A(void);     /* 0xFF5A Periodic Interrupt Timer 6 */          
interrupt void _S12_VEC_5C(void);     /* 0xFF5C Periodic Interrupt Timer 5 */          
interrupt void _S12_VEC_5E(void);     /* 0xFF5E Periodic Interrupt Timer 4 */          
interrupt void _S12_VEC_60(void);     /* 0xFF60 RESERVED */
interrupt void _S12_VEC_62(void);     /* 0xFF62 RESERVED */
interrupt void _S12_VEC_64(void);     /* 0xFF64 XGATE Software Trigger 7 */
interrupt void _S12_VEC_66(void);     /* 0xFF66 XGATE Software Trigger 6 */
interrupt void _S12_VEC_68(void);     /* 0xFF68 XGATE Software Trigger 5 */
interrupt void _S12_VEC_6A(void);     /* 0xFF6A XGATE Software Trigger 4 */
interrupt void _S12_VEC_6C(void);     /* 0xFF6C XGATE Software Trigger 3 */
interrupt void _S12_VEC_6E(void);     /* 0xFF6E XGATE Software Trigger 2 */
interrupt void _S12_VEC_70(void);     /* 0xFF70 XGATE Software Trigger 1 */
interrupt void _S12_VEC_72(void);     /* 0xFF72 XGATE Software Trigger 0 */
interrupt void _S12_VEC_74(void);     /* 0xFF74 Periodic Interrupt Timer 3 */
interrupt void _S12_VEC_76(void);     /* 0xFF76 Periodic Interrupt Timer 2 */
interrupt void _S12_VEC_78(void);     /* 0xFF78 Periodic Interrupt Timer 1 */
interrupt void _S12_VEC_7A(void);     /* 0xFF7A Periodic Interrupt Timer 0 */
interrupt void _S12_VEC_7C(void);     /* 0xFF7C RESERVED */
interrupt void _S12_VEC_7E(void);     /* 0xFF7E API Autonomous Periodical Interrupt */
interrupt void _S12_VEC_80(void);     /* 0xFF80 LVI Low Voltage Interrupt */
interrupt void _S12_VEC_82(void);     /* 0xFF82 IIC1 */
interrupt void _S12_VEC_84(void);     /* 0xFF84 SCI5 */
interrupt void _S12_VEC_86(void);     /* 0xFF86 SCI4 */
interrupt void _S12_VEC_88(void);     /* 0xFF88 SCI3 */
interrupt void _S12_VEC_8A(void);     /* 0xFF8A SCI2 */
interrupt void _S12_VEC_8C(void);     /* 0xFF8C PWM Emergency Shutdown */
interrupt void _S12_VEC_8E(void);     /* 0xFF8E Port P Interrupt */
interrupt void _S12_VEC_90(void);     /* 0xFF90 MSCAN 4 transmit */
interrupt void _S12_VEC_92(void);     /* 0xFF92 MSCAN 4 receive */
interrupt void _S12_VEC_94(void);     /* 0xFF94 MSCAN 4 errors */
interrupt void _S12_VEC_96(void);     /* 0xFF96 MSCAN 4 wake-up */
interrupt void _S12_VEC_98(void);     /* 0xFF98 MSCAN 3 transmit */
interrupt void _S12_VEC_9A(void);     /* 0xFF9A MSCAN 3 receive */
interrupt void _S12_VEC_9C(void);     /* 0xFF9C MSCAN 3 errors */
interrupt void _S12_VEC_9E(void);     /* 0xFF9E MSCAN 3 wake-up */
interrupt void _S12_VEC_A0(void);     /* 0xFFA0 MSCAN 2 transmit */
interrupt void _S12_VEC_A2(void);     /* 0xFFA2 MSCAN 2 receive */
interrupt void _S12_VEC_A4(void);     /* 0xFFA4 MSCAN 2 errors */
interrupt void _S12_VEC_A6(void);     /* 0xFFA6 MSCAN 2 wake-up */
interrupt void _S12_VEC_A8(void);     /* 0xFFA8 MSCAN 1 transmit */
interrupt void _S12_VEC_AA(void);     /* 0xFFAA MSCAN 1 receive */
interrupt void _S12_VEC_AC(void);     /* 0xFFAC MSCAN 1 errors */
interrupt void _S12_VEC_AE(void);     /* 0xFFAE MSCAN 1 wake-up */
interrupt void _S12_VEC_B0(void);     /* 0xFFB0 MSCAN 0 transmit */
interrupt void _S12_VEC_B2(void);     /* 0xFFB2 MSCAN 0 receive */
interrupt void _S12_VEC_B4(void);     /* 0xFFB4 MSCAN 0 errors */
interrupt void _S12_VEC_B6(void);     /* 0xFFB6 MSCAN 0 wake-up */
interrupt void _S12_VEC_B8(void);     /* 0xFFB8 Flash */
interrupt void _S12_VEC_BA(void);     /* 0xFFBA EEPROM */
interrupt void _S12_VEC_BC(void);     /* 0xFFBC SPI2 */
interrupt void _S12_VEC_BE(void);     /* 0xFFBE SPI1 */
interrupt void _S12_VEC_C0(void);     /* 0xFFC0 IIC0 */
interrupt void _S12_VEC_C2(void);     /* 0xFFC2 SCI6 */
interrupt void _S12_VEC_C4(void);     /* 0xFFC4 CRG Self Clock Mode */
interrupt void _S12_VEC_C6(void);     /* 0xFFC6 CRG PLL lock */
interrupt void _S12_VEC_C8(void);     /* 0xFFC8 Pulse accumulator B overflow */
interrupt void _S12_VEC_CA(void);     /* 0xFFCA Modulus Down Counter Underflow */
interrupt void _S12_VEC_CC(void);     /* 0xFFCC Port H */
interrupt void _S12_VEC_CE(void);     /* 0xFFCE Port J */
interrupt void _S12_VEC_D0(void);     /* 0xFFD0 ATD1 */
interrupt void _S12_VEC_D2(void);     /* 0xFFD2 ATD0 */
interrupt void _S12_VEC_D4(void);     /* 0xFFD4 SCI1 */
interrupt void _S12_VEC_D6(void);     /* 0xFFD6 SCI0 */
interrupt void _S12_VEC_D8(void);     /* 0xFFD8 SPI0 */
interrupt void _S12_VEC_DA(void);     /* 0xFFDA Pulse accumulator input edge */
interrupt void _S12_VEC_DC(void);     /* 0xFFDC Pulse accumulator A overflow */
interrupt void _S12_VEC_DE(void);     /* 0xFFDE Enhanced Capture Timer overflow */
interrupt void _S12_VEC_E0(void);     /* 0xFFE0 Enhanced Capture Timer channel 7 */
interrupt void _S12_VEC_E2(void);     /* 0xFFE2 Enhanced Capture Timer channel 6 */
interrupt void _S12_VEC_E4(void);     /* 0xFFE4 Enhanced Capture Timer channel 5 */
interrupt void _S12_VEC_E6(void);     /* 0xFFE6 Enhanced Capture Timer channel 4 */
interrupt void _S12_VEC_E8(void);     /* 0xFFE8 Enhanced Capture Timer channel 3 */
interrupt void _S12_VEC_EA(void);     /* 0xFFEA Enhanced Capture Timer channel 2 */
interrupt void _S12_VEC_EC(void);     /* 0xFFEC Enhanced Capture Timer channel 1 */
interrupt void _S12_VEC_EE(void);     /* 0xFFEE Enhanced Capture Timer channel 0 */
interrupt void _S12_VEC_F0(void);     /* 0xFFF0 Real Time Interrupt */
interrupt void _S12_VEC_F2(void);     /* 0xFFF2 IRQ */
interrupt void _S12_VEC_F4(void);     /* 0xFFF4 XIRQ */
interrupt void _S12_VEC_F6(void);     /* 0xFFF6 SWI */
interrupt void _S12_VEC_F8(void);     /* 0xFFF8 Unallocated instruction trap */
interrupt void _S12_VEC_FA(void);     /* 0xFFFA COP failure reset */
interrupt void _S12_VEC_FC(void);     /* 0xFFFC Clock monitor fail reset */
interrupt void _S12_VEC_FE(void);     /* 0xFFFE Reset vector */

/************************* #defines ******************************************/
/* in s12x_vectors.h */
/************************* Constants *****************************************/
#pragma CONST_SEG DEFAULT
/************************* Global Variables **********************************/
#pragma DATA_SEG DEFAULT
/************************* Functions *****************************************/
//#pragma CODE_SEG __NEAR_SEG NON_BANKED 

#include <non_bank.sgm>
/******************************************************************************
Function Name  : Default_ISR
Engineer       : r27624	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : Interrupt service routine for unused interrupt vectors. 
******************************************************************************/
#pragma TRAP_PROC [SAVE_NO_REGS]
void 
Default_ISR(void)
{
   asm BGND;
}

#pragma CODE_SEG DEFAULT


#pragma CONST_SEG __NEAR_SEG S12_VEC_TABLE
/*****************************************************************************
ResetVectorTable
Interrupt vector table for S12XDP512 
This is the default CPU interrupt vector table at reset: IVBR = $FF
Other vector tables can be created and used by changing IVBR
*****************************************************************************/
/* vector table to be located at address 0xFF00 */
const void (*const near _vectab[])(void) = 
{                             
	(void (*near const)(void))KEY0,		   /* 0xFF00 backdoor key 0 */
	(void (*near const)(void))KEY1,		   /* 0xFF02 backdoor key 1 */
	(void (*near const)(void))KEY2,		   /* 0xFF04 backdoor key 2 */
	(void (*near const)(void))KEY3,		   /* 0xFF06 backdoor key 3 */
	(void (*near const)(void))0xFFFF,		/* 0xFF08 reserved */
	(void (*near const)(void))0xFFFF,		/* 0xFF0A reserved */ 
	(void (*near const)(void))((EPROT<<8)|FPROT),	/* 0xFF0C protection */ 
	(void (*near const)(void))((NVBYT<<8)|FSEC),		/* 0xFF0E security */
    _S12_VEC_10,                 /* 0xFF10 Spurious Interrupt */
    _S12_VEC_12,                 /* 0xFF12 SYS - System interrupt */
    _S12_VEC_14,                 /* 0xFF14 MPU Access error */
    _S12_VEC_16,                 /* 0xFF16 XGATE error */
    ReservedISR,                 /* 0xFF18 Reserved */
    ReservedISR,                 /* 0xFF1A Reserved */
    ReservedISR,                 /* 0xFF1C Reserved */
    ReservedISR,                 /* 0xFF1E Reserved */
    ReservedISR,                 /* 0xFF20 Reserved */
    ReservedISR,                 /* 0xFF22 Reserved */
    ReservedISR,                 /* 0xFF24 Reserved */
    ReservedISR,                 /* 0xFF26 Reserved */
    ReservedISR,                 /* 0xFF28 Reserved */
    ReservedISR,                 /* 0xFF2A Reserved */
    ReservedISR,                 /* 0xFF2C Reserved */
    ReservedISR,                 /* 0xFF2E Reserved */
    ReservedISR,                 /* 0xFF30 Reserved */
    ReservedISR,                 /* 0xFF32 Reserved */
    ReservedISR,                 /* 0xFF34 Reserved */
    ReservedISR,                 /* 0xFF36 Reserved */
    ReservedISR,                 /* 0xFF38 Reserved */
    ReservedISR,                 /* 0xFF3A Reserved */
    _S12_VEC_3C,                 /* 0xFF3C ATD1 compare */                            
    _S12_VEC_3E,                 /* 0xFF3E ATD0 compare */                            
    _S12_VEC_40,                 /* 0xFF40 TIM Pulse accumulator input edge */     
    _S12_VEC_42,                 /* 0xFF42 TIM Pulse accumulator A overflow */     
    _S12_VEC_44,                 /* 0xFF44 TIM overflow */  
    _S12_VEC_46,                 /* 0xFF46 TIM channel 7 */                                 
    _S12_VEC_48,                 /* 0xFF48 TIM channel 6 */ 
    _S12_VEC_4A,                 /* 0xFF4A TIM channel 5 */ 
    _S12_VEC_4C,                 /* 0xFF4C TIM channel 4 */ 
    _S12_VEC_4E,                 /* 0xFF4E TIM channel 3 */ 
    _S12_VEC_50,                 /* 0xFF50 TIM channel 2 */ 
    _S12_VEC_52,                 /* 0xFF52 TIM channel 1 */ 
    _S12_VEC_54,                 /* 0xFF54 TIM channel 0 */ 
    _S12_VEC_56,                 /* 0xFF56 SCI7 */                     
    _S12_VEC_58,                 /* 0xFF58 Periodic Interrupt Timer 7 */          
    _S12_VEC_5A,                 /* 0xFF5A Periodic Interrupt Timer 6 */          
    _S12_VEC_5C,                 /* 0xFF5C Periodic Interrupt Timer 5 */          
    _S12_VEC_5E,                 /* 0xFF5E Periodic Interrupt Timer 4 */          
    ReservedISR,                 /* 0xFF60 Reserved */
    ReservedISR,                 /* 0xFF62 Reserved */
    _S12_VEC_64,                 /* 0xFF64 XGATE Software Trigger 7 */
    _S12_VEC_66,                 /* 0xFF66 XGATE Software Trigger 6 */
    _S12_VEC_68,                 /* 0xFF68 XGATE Software Trigger 5 */
    _S12_VEC_6A,                 /* 0xFF6A XGATE Software Trigger 4 */
    _S12_VEC_6C,                 /* 0xFF6C XGATE Software Trigger 3 */
    _S12_VEC_6E,                 /* 0xFF6E XGATE Software Trigger 2 */
    _S12_VEC_70,                 /* 0xFF70 XGATE Software Trigger 1 */
    _S12_VEC_72,                 /* 0xFF72 XGATE Software Trigger 0 */
    _S12_VEC_74,                 /* 0xFF74 Periodic Interrupt Timer 3 */
    _S12_VEC_76,                 /* 0xFF76 Periodic Interrupt Timer 2 */
    _S12_VEC_78,                 /* 0xFF78 Periodic Interrupt Timer 1 */
    _S12_VEC_7A,                 /* 0xFF7A Periodic Interrupt Timer 0 */
    _S12_VEC_7C,                 /* 0xFF7C Reserved */
    _S12_VEC_7E,                 /* 0xFF7E API Autonomous Periodical Interrupt */
    _S12_VEC_80,                 /* 0xFF80 LVI Low Voltage Interrupt */
    _S12_VEC_82,                 /* 0xFF82 IIC1 */
    _S12_VEC_84,                 /* 0xFF84 SCI5 */
    _S12_VEC_86,                 /* 0xFF86 SCI4 */
    _S12_VEC_88,                 /* 0xFF88 SCI3 */
    _S12_VEC_8A,                 /* 0xFF8A SCI2 */
    _S12_VEC_8C,                 /* 0xFF8C PWM Emergency Shutdown */
    _S12_VEC_8E,                 /* 0xFF8E Port P Interrupt */
    _S12_VEC_90,                 /* 0xFF90 MSCAN 4 transmit */
    _S12_VEC_92,                 /* 0xFF92 MSCAN 4 receive */
    _S12_VEC_94,                 /* 0xFF94 MSCAN 4 errors */
    _S12_VEC_96,                 /* 0xFF96 MSCAN 4 wake-up */
    _S12_VEC_98,                 /* 0xFF98 MSCAN 3 transmit */
    _S12_VEC_9A,                 /* 0xFF9A MSCAN 3 receive */
    _S12_VEC_9C,                 /* 0xFF9C MSCAN 3 errors */
    _S12_VEC_9E,                 /* 0xFF9E MSCAN 3 wake-up */
    _S12_VEC_A0,                 /* 0xFFA0 MSCAN 2 transmit */
    _S12_VEC_A2,                 /* 0xFFA2 MSCAN 2 receive */
    _S12_VEC_A4,                 /* 0xFFA4 MSCAN 2 errors */
    _S12_VEC_A6,                 /* 0xFFA6 MSCAN 2 wake-up */
    _S12_VEC_A8,                 /* 0xFFA8 MSCAN 1 transmit */
    _S12_VEC_AA,                 /* 0xFFAA MSCAN 1 receive */
    _S12_VEC_AC,                 /* 0xFFAC MSCAN 1 errors */
    _S12_VEC_AE,                 /* 0xFFAE MSCAN 1 wake-up */
    _S12_VEC_B0,                 /* 0xFFB0 MSCAN 0 transmit */
    _S12_VEC_B2,                 /* 0xFFB2 MSCAN 0 receive */
    _S12_VEC_B4,                 /* 0xFFB4 MSCAN 0 errors */
    _S12_VEC_B6,                 /* 0xFFB6 MSCAN 0 wake-up */
    _S12_VEC_B8,                 /* 0xFFB8 Flash */
    _S12_VEC_BA,                 /* 0xFFBA Flash error detect */
    _S12_VEC_BC,                 /* 0xFFBC SPI2 */
    _S12_VEC_BE,                 /* 0xFFBE SPI1 */
    _S12_VEC_C0,                 /* 0xFFC0 IIC0 */
    _S12_VEC_C2,                 /* 0xFFC2 SCI6 */
    _S12_VEC_C4,                 /* 0xFFC4 CRG Self Clock Mode */
    _S12_VEC_C6,                 /* 0xFFC6 CRG PLL lock */
    _S12_VEC_C8,                 /* 0xFFC8 Pulse accumulator B overflow */
    _S12_VEC_CA,                 /* 0xFFCA Modulus Down Counter Underflow */
    _S12_VEC_CC,                 /* 0xFFCC Port H */
    _S12_VEC_CE,                 /* 0xFFCE Port J */
    _S12_VEC_D0,                 /* 0xFFD0 ATD1 */
    _S12_VEC_D2,                 /* 0xFFD2 ATD0 */
    _S12_VEC_D4,                 /* 0xFFD4 SCI1 */
    _S12_VEC_D6,                 /* 0xFFD6 SCI0 */
    _S12_VEC_D8,                 /* 0xFFD8 SPI0 */
    _S12_VEC_DA,                 /* 0xFFDA Pulse accumulator input edge */
    _S12_VEC_DC,                 /* 0xFFDC Pulse accumulator A overflow */
    _S12_VEC_DE,                 /* 0xFFDE Enhanced Capture Timer overflow */
    _S12_VEC_E0,                 /* 0xFFE0 Enhanced Capture Timer channel 7 */
    _S12_VEC_E2,                 /* 0xFFE2 Enhanced Capture Timer channel 6 */
    _S12_VEC_E4,                 /* 0xFFE4 Enhanced Capture Timer channel 5 */
    _S12_VEC_E6,                 /* 0xFFE6 Enhanced Capture Timer channel 4 */
    _S12_VEC_E8,                 /* 0xFFE8 Enhanced Capture Timer channel 3 */
    _S12_VEC_EA,                 /* 0xFFEA Enhanced Capture Timer channel 2 */
    _S12_VEC_EC,                 /* 0xFFEC Enhanced Capture Timer channel 1 */
    _S12_VEC_EE,                 /* 0xFFEE Enhanced Capture Timer channel 0 */
    _S12_VEC_F0,                 /* 0xFFF0 Real Time Interrupt (Channel 78) */
    _S12_VEC_F2,                 /* 0xFFF2 IRQ */
    _S12_VEC_F4,                 /* 0xFFF4 XIRQ */
    _S12_VEC_F6,                 /* 0xFFF6 SWI */
    _S12_VEC_F8,                 /* 0xFFF8 Unallocated instruction trap */
    _S12_VEC_FA,                 /* 0xFFFA COP failure reset */
    _S12_VEC_FC,                 /* 0xFFFC Clock monitor fail reset */
    _S12_VEC_FE                  /* 0xFFFE Reset vector */
};
