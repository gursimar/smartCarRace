/******************************************************************************
													            Copyright (c) Freescale 2005
File Name	 :	$RCSfile: XGate_vectors.h,v $

Engineer		 :	$Author: r32151 $

Location		 :	EKB

Date Created	  :	02/03/2005

Current Revision :	$Revision: 1.0 $

Notes            :  

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

#ifndef XGATE_VECTORS_H
#define XGATE_VECTORS_H

/************************* typedefs ******************************************/
typedef struct {
  void (*isr)(void);	  /* address of the routine itself */
  void *const data;	  /* private data of that routine */	
} xgate_vector;

/************************* Global Variables **********************************/
#pragma CONST_SEG XGATE_CONST
extern const xgate_vector XgateVectorTable[];	/* Xgate vector table */

#pragma DATA_SEG DEFAULT
/* used with XGATE_CODE section (see prm file) */

extern char __SEG_START_XGATE_CODE[];
#define XGATE_ROM_CODE_START ((void*)__SEG_START_XGATE_CODE)

extern char __SEG_SIZE_XGATE_CODE[];
#define XGATE_CODE_SIZE ((int)__SEG_SIZE_XGATE_CODE)

extern char __SEG_RELOCATE_TO_XGATE_CODE[];
#define XGATE_RAM_CODE_START ((void*)__SEG_RELOCATE_TO_XGATE_CODE)

/************************* function prototypes *******************************/
#pragma CODE_SEG XGATE_CODE

/************************* #defines ******************************************/
/* see variable definition of XgateVectorTable in xgate_vectors.cxgate */
#define XVEC_TABLE_OFFSET 0x0078		 /* for S12XE100 */

#endif /* XGATE_VECTORS_H */
