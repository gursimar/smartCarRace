/******************************************************************************
													Copyright (c) Freescale 2006
File Name    : $RCSfile: InterruptConfig.c,v $

Engineer     : $Author: r32151 $

Location     : EKB

Date Created : 11/5/2005

Current Revision :	$Revision: 1.1 $

Notes        : Routines for configuring the S12X interrupt system including 
               the XGate interrupt co processor (which requires copying of 
               it's code to RAM).
               The priority of each interrupt source and whether it is to be
               serviced by the Core CPU or the XGate is assigned in a simple 
               table which should be modified as required. 
             
             **************************************************************** 
             * SIZE OF THE TWO XGATE STACKS MUST BE DEFINED IN INTERRPUTS.H *
.				 ****************************************************************



               
UPDATE HISTORY                                                            
REV  AUTHOR    DATE        DESCRIPTION OF CHANGE                          
---  ------    --------    ---------------------                          
1.0  r32151    01/03/05    - initial coding
1.1  r32151    26/01/06    - Changed initialisation of the XGATE stacks
                             to use two arrays XgateHiStack[] and 
                             XgateLoStack[]. This allows the XGATE RAM
                             memory map to be modified without changing the 
                             source code addresses.
                             Size of the arrays need to be defined in 
                             interrupts.h.
                             Updated ConfigureInterrupts to reference the
                             arrays when initialising the XGATE registers.             
 
     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

/************************* Include Files *************************************/
#include "s12x_peripherals.h"
#include "target.h"
#include "InterruptConfig.h"
#include "Xgate_vectors.h"
#include "s12x_vectors.h"
#include "interrupts.h"

/************************* typedefs ******************************************/
/* in InterruptConfig.h */

/************************* #defines ******************************************/
/* in InterruptConfig.h */

#ifdef XG_FREEZES
#define _XGFRZ XGFRZ
#else
#define _XGFRZ 0
#endif

#ifdef XG_FAKE_ACTIVITY
#define _XGFACT XGFACT
#else
#define _XGFACT 0
#endif

/************************* Constants *****************************************/
#pragma CONST_SEG DEFAULT

/************************* Global Variables **********************************/
#pragma DATA_SEG XGATE_STACKS
/* these two arrays are used to define space in the XGATE RAM for the low and
   high priority stacks. They not are referenced in the application as they 
   are only used implicitly for XGATE stack operations. */
volatile unsigned int XgateHiStack[XGATE_HI_STACK_SIZE];
volatile unsigned int XgateLoStack[XGATE_LO_STACK_SIZE];

#pragma DATA_SEG DEFAULT

/************************* function prototypes *******************************/
/* in InterruptConfig.h */

/************************* Functions *****************************************/
#pragma CODE_SEG DEFAULT

/*****************************************************************************
InterruptConfigurationTable.
Interrupt configuration table for S12XDP512. 
This is the configuration table for interrupt requests used to set the priority
and whether it is handled by the CPU or XGATE
The data in this table must be copied to the banks of INT_CFDATA0..7 registers.

			 *******************************************************
          *   Priority Level can be from PRIOLVL1 to PRIOLVL7   *
			 *******************************************************
          * To route servicing to Xgate change to PRIOLVLx|RQST *
          *******************************************************
             
*****************************************************************************/
const unsigned char InterruptConfigurationTable[] = 
{                                      
    _INT_PRI_3C | _INT_SER_3C,                 /* 0x3C ATD1 compare                       (XG Channel 1E) */                           
    _INT_PRI_3E | _INT_SER_40,                 /* 0x3E ATD0 compare                       (XG Channel 1F) */                           
    _INT_PRI_40 | _INT_SER_42,                 /* 0x40 TIM Pulse accumulator input edge   (XG Channel 20) */    
    _INT_PRI_42 | _INT_SER_42,                 /* 0x42 TIM Pulse accumulator A overflow   (XG Channel 21) */    
    _INT_PRI_44 | _INT_SER_44,                 /* 0x44 TIM overflow                       (XG Channel 22) */
    _INT_PRI_46 | _INT_SER_46,                 /* 0x46 TIM channel 7                      (XG Channel 23) */                                
    _INT_PRI_48 | _INT_SER_48,                 /* 0x48 TIM channel 6                      (XG Channel 24) */
    _INT_PRI_4A | _INT_SER_4A,                 /* 0x4A TIM channel 5                      (XG Channel 25) */
    _INT_PRI_4C | _INT_SER_4C,                 /* 0x4C TIM channel 4                      (XG Channel 26) */
    _INT_PRI_4E | _INT_SER_4E,                 /* 0x4E TIM channel 3                      (XG Channel 27) */
    _INT_PRI_50 | _INT_SER_50,                 /* 0x50 TIM channel 2                      (XG Channel 28) */
    _INT_PRI_52 | _INT_SER_52,                 /* 0x52 TIM channel 1                      (XG Channel 29) */
    _INT_PRI_54 | _INT_SER_54,                 /* 0x54 TIM channel 0                      (XG Channel 2A) */
    _INT_PRI_56 | _INT_SER_56,                 /* 0x56 SCI7                               (XG Channel 2B) */           
    _INT_PRI_58 | _INT_SER_58,                 /* 0x58 Periodic Interrupt Timer 7         (XG Channel 2C) */         
    _INT_PRI_5A | _INT_SER_5A,                 /* 0x5A Periodic Interrupt Timer 6         (XG Channel 2D) */         
    _INT_PRI_5C | _INT_SER_5C,                 /* 0x5C Periodic Interrupt Timer 5         (XG Channel 2E) */         
    _INT_PRI_5E | _INT_SER_5E,                 /* 0x5E Periodic Interrupt Timer 4         (XG Channel 2F) */         
    _INT_PRI_60 | _INT_SER_60,                 /* 0x60 Reserved                           (XG Channel 30) */
    _INT_PRI_62 | _INT_SER_62,                 /* 0x62 Reserved                           (XG Channel 31) */
    _INT_PRI_64 | _INT_SER_64,                 /* 0x64 XGATE Software Trigger 7           (XG Channel 32) */
    _INT_PRI_66 | _INT_SER_66,                 /* 0x66 XGATE Software Trigger 6           (XG Channel 33) */
    _INT_PRI_68 | _INT_SER_68,                 /* 0x68 XGATE Software Trigger 5           (XG Channel 34) */
    _INT_PRI_6A | _INT_SER_6A,                 /* 0x6A XGATE Software Trigger 4           (XG Channel 35) */
    _INT_PRI_6C | _INT_SER_6C,                 /* 0x6C XGATE Software Trigger 3           (XG Channel 36) */
    _INT_PRI_6E | _INT_SER_6E,                 /* 0x6E XGATE Software Trigger 2           (XG Channel 37) */
    _INT_PRI_70 | _INT_SER_70,                 /* 0x70 XGATE Software Trigger 1           (XG Channel 38) */
    _INT_PRI_72 | _INT_SER_72,                 /* 0x72 XGATE Software Trigger 0           (XG Channel 39) */
    _INT_PRI_74 | _INT_SER_74,                 /* 0x74 Periodic Interrupt Timer 3         (XG Channel 3A) */
    _INT_PRI_76 | _INT_SER_76,                 /* 0x76 Periodic Interrupt Timer 2         (XG Channel 3B) */
    _INT_PRI_78 | _INT_SER_78,                 /* 0x78 Periodic Interrupt Timer 1         (XG Channel 3C) */
    _INT_PRI_7A | _INT_SER_7A,                 /* 0x7A Periodic Interrupt Timer 0         (XG Channel 3D) */
    _INT_PRI_7C | _INT_SER_7C,                 /* 0x7C Reserved                           (XG Channel 3E) */
    _INT_PRI_7E | _INT_SER_7E,                 /* 0x7E API Autonomous Periodical Interrupt(XG Channel 3F) */
    _INT_PRI_80 | _INT_SER_80,                 /* 0x80 LVI Low Voltage Interrupt          (XG Channel 40) */
    _INT_PRI_82 | _INT_SER_82,                 /* 0x82 IIC1                               (XG Channel 41) */
    _INT_PRI_84 | _INT_SER_84,                 /* 0x84 SCI5                               (XG Channel 42) */
    _INT_PRI_86 | _INT_SER_86,                 /* 0x86 SCI4                               (XG Channel 43) */
    _INT_PRI_88 | _INT_SER_88,                 /* 0x88 SCI3                               (XG Channel 44) */
    _INT_PRI_8A | _INT_SER_8A,                 /* 0x8A SCI2                               (XG Channel 45) */
    _INT_PRI_8C | _INT_SER_8C,                 /* 0x8C PWM Emergency Shutdown             (XG Channel 46) */
    _INT_PRI_8E | _INT_SER_8E,                 /* 0x8E Port P Interrupt                   (XG Channel 47) */
    _INT_PRI_90 | _INT_SER_90,                 /* 0x90 MSCAN 4 transmit                   (XG Channel 48) */
    _INT_PRI_92 | _INT_SER_92,                 /* 0x92 MSCAN 4 receive                    (XG Channel 49) */
    _INT_PRI_94 | _INT_SER_94,                 /* 0x94 MSCAN 4 errors                     (XG Channel 4A) */
    _INT_PRI_96 | _INT_SER_96,                 /* 0x96 MSCAN 4 wake-up                    (XG Channel 4B) */
    _INT_PRI_98 | _INT_SER_98,                 /* 0x98 MSCAN 3 transmit                   (XG Channel 4C) */
    _INT_PRI_9A | _INT_SER_9A,                 /* 0x9A MSCAN 3 receive                    (XG Channel 4D) */
    _INT_PRI_9C | _INT_SER_9C,                 /* 0x9C MSCAN 3 errors                     (XG Channel 4E) */
    _INT_PRI_9E | _INT_SER_9E,                 /* 0x9E MSCAN 3 wake-up                    (XG Channel 4F) */
    _INT_PRI_A0 | _INT_SER_A0,                 /* 0xA0 MSCAN 2 transmit                   (XG Channel 50) */
    _INT_PRI_A2 | _INT_SER_A2,                 /* 0xA2 MSCAN 2 receive                    (XG Channel 51) */
    _INT_PRI_A4 | _INT_SER_A4,                 /* 0xA4 MSCAN 2 errors                     (XG Channel 52) */
    _INT_PRI_A6 | _INT_SER_A6,                 /* 0xA6 MSCAN 2 wake-up                    (XG Channel 53) */
    _INT_PRI_A8 | _INT_SER_A8,                 /* 0xA8 MSCAN 1 transmit                   (XG Channel 54) */
    _INT_PRI_AA | _INT_SER_AA,                 /* 0xAA MSCAN 1 receive                    (XG Channel 55) */
    _INT_PRI_AC | _INT_SER_AC,                 /* 0xAC MSCAN 1 errors                     (XG Channel 56) */
    _INT_PRI_AE | _INT_SER_AE,                 /* 0xAE MSCAN 1 wake-up                    (XG Channel 57) */
    _INT_PRI_B0 | _INT_SER_B0,                 /* 0xB0 MSCAN 0 transmit                   (XG Channel 58) */
    _INT_PRI_B2 | _INT_SER_B2,                 /* 0xB2 MSCAN 0 receive                    (XG Channel 59) */
    _INT_PRI_B4 | _INT_SER_B4,                 /* 0xB4 MSCAN 0 errors                     (XG Channel 5A) */
    _INT_PRI_B6 | _INT_SER_B6,                 /* 0xB6 MSCAN 0 wake-up                    (XG Channel 5B) */
    _INT_PRI_B8 | _INT_SER_B8,                 /* 0xB8 Flash                              (XG Channel 5C) */
    _INT_PRI_BA | _INT_SER_BA,                 /* 0xBA Flash error detect                 (XG Channel 5D) */
    _INT_PRI_BC | _INT_SER_BC,                 /* 0xBC SPI2                               (XG Channel 5E) */
    _INT_PRI_BE | _INT_SER_BE,                 /* 0xBE SPI1                               (XG Channel 5F) */
    _INT_PRI_C0 | _INT_SER_C0,                 /* 0xC0 IIC0                               (XG Channel 60) */
    _INT_PRI_C2 | _INT_SER_C2,                 /* 0xC2 SCI6                               (XG Channel 61) */
    _INT_PRI_C4 | _INT_SER_C4,                 /* 0xC4 CRG Self Clock Mode                (XG Channel 62) */
    _INT_PRI_C6 | _INT_SER_C6,                 /* 0xC6 CRG PLL lock                       (XG Channel 63) */
    _INT_PRI_C8 | _INT_SER_C8,                 /* 0xC8 Pulse accumulator B overflow       (XG Channel 64) */
    _INT_PRI_CA | _INT_SER_CA,                 /* 0xCA Modulus Down Counter Underflow     (XG Channel 65) */
    _INT_PRI_CC | _INT_SER_CC,                 /* 0xCC Port H                             (XG Channel 66) */
    _INT_PRI_CE | _INT_SER_CE,                 /* 0xCE Port J                             (XG Channel 67) */
    _INT_PRI_D0 | _INT_SER_D0,                 /* 0xD0 ATD1                               (XG Channel 68) */
    _INT_PRI_D2 | _INT_SER_D2,                 /* 0xD2 ATD0                               (XG Channel 69) */
    _INT_PRI_D4 | _INT_SER_D4,                 /* 0xD4 SCI1                               (XG Channel 6A) */
    _INT_PRI_D6 | _INT_SER_D6,                 /* 0xD6 SCI0                               (XG Channel 6B) */
    _INT_PRI_D8 | _INT_SER_D8,                 /* 0xD8 SPI0                               (XG Channel 6C) */
    _INT_PRI_DA | _INT_SER_DA,                 /* 0xDA ECT Pulse accumulator input edge   (XG Channel 6D) */
    _INT_PRI_DC | _INT_SER_DC,                 /* 0xDC ECT Pulse accumulator A overflow   (XG Channel 6E) */
    _INT_PRI_DE | _INT_SER_DE,                 /* 0xDE Enhanced Capture Timer overflow    (XG Channel 6F) */
    _INT_PRI_E0 | _INT_SER_E0,                 /* 0xE0 Enhanced Capture Timer channel 7   (XG Channel 70) */
    _INT_PRI_E2 | _INT_SER_E2,                 /* 0xE2 Enhanced Capture Timer channel 6   (XG Channel 71) */
    _INT_PRI_E4 | _INT_SER_E4,                 /* 0xE4 Enhanced Capture Timer channel 5   (XG Channel 72) */
    _INT_PRI_E6 | _INT_SER_E6,                 /* 0xE6 Enhanced Capture Timer channel 4   (XG Channel 73) */
    _INT_PRI_E8 | _INT_SER_E8,                 /* 0xE8 Enhanced Capture Timer channel 3   (XG Channel 74) */
    _INT_PRI_EA | _INT_SER_EA,                 /* 0xEA Enhanced Capture Timer channel 2   (XG Channel 75) */
    _INT_PRI_EC | _INT_SER_EC,                 /* 0xEC Enhanced Capture Timer channel 1   (XG Channel 76) */
    _INT_PRI_EE | _INT_SER_EE,                 /* 0xEE Enhanced Capture Timer channel 0   (XG Channel 77) */
    _INT_PRI_F0 | _INT_SER_F0,                 /* 0xF0 Real Time Interrupt                (XG Channel 78) */
    _INT_PRI_F2                                /* 0xF2 IRQ - Priority level only */
};

/******************************************************************************
Function Name	: ConfigureInterruptPriorities
Engineer		   : r32151
Date			   : 31/10/2005						
Parameters		: configTable - pointer to config table
Return			: none	 
Notes			   : configures priority and routing for each interrupt source.
                 Rewritten from previous pjoject to replace two for loops
                 with the do while loop making it 	
******************************************************************************/
void 
ConfigureInterruptPriorities(const unsigned char *configTable)
{
	unsigned char i;
	Interrupt.ivbr = CPU_VECTOR_BASE;  /* set vector table base - defeult is 0xFF */

                           /* configure all vector routing an priorities  */
   Interrupt.cfaddr = FIRST_VEC & 0xF0;   /* select inital cf bank */
   i = (FIRST_VEC & 0x0F) / 2;				/* select initial cf index */
   do
   {
      Interrupt.cfdata[i++].byte = *configTable++;
      if (i > 7)
      {
         i = 0;
         Interrupt.cfaddr += 0x10;
      }
   }while ((Interrupt.cfaddr != 0xF0) || (i < 2));
										
  	Interrupt.xgprio = _XGATE_PRI;    /* set XGATE priority level */
                                     /* write the interrupt vector base register */
   Interrupt.ivbr = (tU08)(((tU16)_vectab)>>8);
}

/******************************************************************************
Function Name	: CopyXGateCode
Engineer		   : Metrowerks	
Parameters		: None
Returns			: None
Notes			   : This routine copies the Xgate code from Flash to RAM (with a
                 version of MemCopy optimised to use global addressing, 
                 Usually there is no need to modify this routine.
                 In released version of Metrowerks this is done in start12.c.
******************************************************************************/
void 
CopyXGateCode(void)
{
  __asm {
    LDX   #__SEG_START_XGATE_CODE
    LDAB  #PAGE(__SEG_START_XGATE_CODE)
    LDY   #GLOBAL(__SEG_RELOCATE_TO_XGATE_CODE)
    LDAA  #GLOBAL_PAGE(__SEG_RELOCATE_TO_XGATE_CODE)
    JSR   _FAR_COPY_LOGICAL_GLOBAL_RC;
    DC.W  LOGICAL(__SEG_SIZE_XGATE_CODE)
  }
}

/******************************************************************************
Function Name	: ConfigureInterrupts
Engineer		   : r32151	
Date			   : 09/09/2005
Parameters		: usingXgate - used to gate whether to initialise the XGate 
                 module or not. Should only = XGATE_ON if an entry in the 
                 Interrupt Configuration Table has the RQST bit set.
                 Call as #define XGATE_ON / XGATE_OFF

					  download - controls whether to copy code to RAM or not
                 Call as XGATE_CODE_LOADED_BY_CONFIG / XGATE_CODE_LOADED_BY_STARTUP

Returns			: None
Notes			   : This routine performs the recommended initialisation routine
                 from the XGate Block User Guide. In doing so it also configures 
                 the interrupt priority levels for S12 interrupts.
                 The usingXgate parameter should only = XGATE_ON if an entry in 
                 the Interrupt Configuration Table has the RQST bit set.
                 Usually there is no need to modify this routine.
                 Updated version to set the Stack pointers for XGATE V3.
                 Updated to initialise the XGATE stack pointers to utilise the 
                 memory allocated to XgateHiStack[] and XgateLoStack[] arrays. 
******************************************************************************/
void 
ConfigureInterrupts(char usingXgate, char download)
{
   volatile tU16 *chIdPtr = &XGATE.xgif_70;
      /* ensure XGE, XGDBG & XGSWEIF(write one to clear) = 0 */
   if (usingXgate == XGATE_ON)
   {
       XGATE.xgmctl = XGSWEF | XGSWEFM;
           /* ensure XGate is idle */ 
       while (XGATE.xgchid !=0) { /* wait */ }
			  /* index to vector base register */
		 XGATE.xgispsel.bit.xgispsel = VBR_SEL;
           /* configure XGate Vector base register to point at the vector table */
       XGATE.xgvbr = (tU16)((void *__far)XgateVectorTable) - XVEC_TABLE_OFFSET;	/* initialise Xgate vector base */
			  /* index to low priority stack base register */
		 XGATE.xgispsel.bit.xgispsel = STACK_LO_SEL;
			  /* set the low priority stack start address */
       XGATE.xgvbr =  (tU16)(char *__far)XgateLoStack + sizeof(XgateLoStack);
			  /* index to high priority stack base register */
		 XGATE.xgispsel.bit.xgispsel = STACK_HI_SEL;
			  /* set the high priority stack start address */
       XGATE.xgvbr =  (tU16)(char *__far)XgateHiStack + sizeof(XgateHiStack);
           /* clear XGate channel interrupt flags - chIdPtr is initialised to xgif_70 */
       do {
           *chIdPtr = 0xFFFF;  /* flags = 1 to clear */
       } while(chIdPtr++ != &XGATE.xgif_00);
           /* clear any software trigger flags */  
       XGATE.xgswt.word = 0xFF00;
       if (download == XGATE_CODE_LOADED_BY_CONFIG)
       {       /* copy XGate code */
          CopyXGateCode();
       }
           /* initialise interrupt priorities and routing */
       ConfigureInterruptPriorities(InterruptConfigurationTable);
           /* Xgate configuration */
       XGATE.xgmctl = XGE | XGIE | XGSWEF | _XGFRZ | _XGFACT |0xFF00;	
   } 
   else 
   {
      /* initialise interrupt priorities and routing */
      ConfigureInterruptPriorities(InterruptConfigurationTable);
   }
}