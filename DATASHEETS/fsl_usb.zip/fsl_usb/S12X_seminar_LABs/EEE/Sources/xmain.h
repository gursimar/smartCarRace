/******************************************************************************
													            Copyright (c) Freescale 2005
File Name    : $RCSfile: xmain.h,v $

Current Revision :	$Revision: 1.0 $

PURPOSE: Header file for xmain.cxgate XGate Service Routines.                       
                                                                          
DESCRIPTION:  Header file for xmain.cxgate XGate Service Routines.                                             
                                                                          
UPDATE HISTORY                                                            
REV  AUTHOR    DATE        DESCRIPTION OF CHANGE                          
---  ------    --------    ---------------------                          
1.0  r32151    01/03/05    - initial coding              

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

                           /*prevent duplicated includes */
#ifndef XMAIN_H       
#define XMAIN_H

/************************* typedefs ******************************************/
/* Note: word / long elements of stuctures for access by XGate should have   */
/* even size i.e. on even boundary and all XGate pointers are 16-bit.        */

/************************* Global Variables **********************************/
#pragma DATA_SEG SHARED


/************************* function prototypes *******************************/
#pragma CODE_SEG XGATE_CODE

#endif /* XMAIN_H */ 