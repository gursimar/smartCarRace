#include "s12x_peripherals.h"
#include "s12xe_flash.h"
#include "sys_params.h"
#include "main.h"
#include "far_ptr.h"

__SEG_SIZE_DEF(SYSTEM_DATA);  // size of system parameter variables

#pragma DATA_SEG SYSTEM_DATA    /* linked into the buffer RAM at 0x0C00 */

int  PARAM_1;            
int  PARAM_2;            
char PARAM_3;            
int  PARAM_4;            
int  PARAM_5;            
tU16 PARAM_6;            
tU16 PARAM_7;
tU16 PARAM_8;
char PARAM_9;
tU16 PARAM_10;
tU16 PARAM_11;
tU16 PARAM_12;
tU16 PARAM_13;
tU08 PARAM_14;    
tU16 PARAM_15;    //27 bytes

#pragma CONST_SEG DEFAULT        

/* these represent static parameters programmed by the application or boot  */
/* loader into the user D-Flash during production (for example).            */
/* In this example these are created as constants in the code that are then */
/* programmed once into the D-Flash (global address 0x100000'G).            */
/* Their order and type should be the same as the variable list in the      */
/* SYSTEM_DATA segment above.                                               */

const int  PARAM_1_NVM  = 0x1111;
const int  PARAM_2_NVM  = 0x2222;
const char PARAM_3_NVM  = 0x33;
const int  PARAM_4_NVM  = 0x4444;
const int  PARAM_5_NVM  = 0x5555;
const tU16 PARAM_6_NVM  = 0x6666;
const tU16 PARAM_7_NVM  = 0x7777;
const tU16 PARAM_8_NVM  = 0x8888;
const char PARAM_9_NVM  = 0x99;
const tU16 PARAM_10_NVM = 0xAAAA;
const tU16 PARAM_11_NVM = 0xBBBB;
const tU16 PARAM_12_NVM = 0xCCCC;
const tU16 PARAM_13_NVM = 0xDDDD;
const tU08 PARAM_14_NVM = 0xEE;
const tU16 PARAM_15_NVM = 0x1234;    //27 bytes

#pragma CODE_SEG DEFAULT

void InitSysParams(void){
   tU16 *__far src_ptr_f16; 
   tU16 *__far dst_ptr_f16 = (tU16 *__far)SYS_PARAM_DFLASH_START;     
   tU08 ftmStat;
   tU16 data[4];
   int i;
   int remainder;

         /* Program default parameters into D-flash if not already loaded */
   if(*dst_ptr_f16 == 0xFFFF){
      FTM.fclkdiv.byte  = FCLK_DIV;    /* write the flash clock divider */
                                       /* before launching first FTM command */
                                       /* but after CCIF flag has set */
      src_ptr_f16 = (tU16 *__far)&PARAM_1_NVM;
         /* program them into D-flash */
         /* write 4 words at a time - would be cleaner to write a dedicated function to take a pointer */
      for(i = (SIZEOF_SYSTEM_DATA / 8); i>0; i--) {
         data[0] = *src_ptr_f16++;
         data[1] = *src_ptr_f16++;
         data[2] = *src_ptr_f16++;
         data[3] = *src_ptr_f16++;
         ftmStat = LaunchFlashCommand(6 ,PROGRAM_D_FLASH, WP_PAGE(dst_ptr_f16), WP_ADDR(dst_ptr_f16), data[0], data[1], data[2], data[3]);
         if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
            Error(ftmStat);    
         FP_ADD(dst_ptr_f16, 8);
      }
         /* write any remaining data  */
      remainder = ((SIZEOF_SYSTEM_DATA % 8) /2);
      for(i = 0; i < remainder; i++ )
         data[i] = *src_ptr_f16++;
      if(SIZEOF_SYSTEM_DATA % 2){
         data[i] = *src_ptr_f16|0x00FF;
         remainder++;
      }
      ftmStat = LaunchFlashCommand(remainder + 2 ,PROGRAM_D_FLASH, WP_PAGE(dst_ptr_f16), WP_ADDR(dst_ptr_f16), data[0], data[1], data[2], data[3]);
      if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
         Error(ftmStat);    
   }
}



