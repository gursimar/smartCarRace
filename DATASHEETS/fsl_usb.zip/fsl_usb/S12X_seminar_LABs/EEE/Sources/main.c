/******************************************************************************
      Copyright (c) Freescale 2006
PURPOSE: Emulated EEPROM Demo
DESCRIPTION:  function main() providing initial program entry.
              function Delay() - simple software delay
              ISR definitions for non maskable CPU interrupts                                             
                                                                          
UPDATE HISTORY                                                            
REV  AUTHOR    DATE        DESCRIPTION OF CHANGE                          
---  ------    --------    ---------------------                          
1.0  r32151    01/03/05    - initial coding
1.1  r32151    26/01/06    - general clean up. 
                             Removed all MPU code.
                             Added NOPs in front of BGND instructions. in ISRs
/************************* Include Files *************************************/
#include <hidef.h>  
#include "s12x_peripherals.h"
#include "target.h"      // includes peripherals definitions and FSL data types 
#include "interruptConfig.h"
//#include "sys_params.h"
#include "main.h"
#include "s12_io.h"
#include "S12XE_Flash.h"

// SET THE SIZE OF THE EEE HERE 
#define EEE_SECTORS 16          // x256 bytes ~ can be 0 to 16

#if(EEE_SECTORS == 1)
   #define DFPART (128 - 12)
#else
   #define DFPART (128 - (8 * EEE_SECTORS))
#endif


/************************* Constants *****************************************/        
#pragma CONST_SEG DEFAULT        
#pragma DATA_SEG SHARED_DATA
#pragma DATA_SEG EEPROM_DATA

volatile tU16 EEE_Int[8];   // Array situated in EEE RAM at 0x0F00'L 
                            // volatile so we can always see the access for evaluation purposes only

#pragma DATA_SEG DEFAULT
#pragma CODE_SEG DEFAULT

/******************************************************************************
Function Name  : main
Engineer       : r32151	
Date           : 01/03/2005
Parameters     : NONE
Returns        : NONE
Notes          : main routine called by Startup.c. 
******************************************************************************/
//#define FORCE_FALL_ERASE  // uncomment this line to re-partition D_Flash 
unsigned char SEC  @0x7FFF0F = 0xFE;
//#define FORCE_PARTITON_FOR_DEBUG   //uncomment this line to partition and clear EEE. This can ONLY beused in DEBUG mode! 

void main(void) 
{
    volatile tU16 temp = 0;
    volatile tU08 ftmStat; 
    volatile tU16 ErrorCount = 0;
    int i;

    unsigned char dfPart, erPart;
    
    while (!FTM.fstat.bit.ccif) {}	// wait for FTM reset to complete 

    FTM.fclkdiv.byte  = FCLK_DIV;   // write the flash clock divider
    if(FTM.fclkdiv.byte != (FCLK_DIV | 0x80))  Error(0);
   
// format eee - special mode only - also erases all D-Flash 
    LaunchFlashCommand(3,FULL_PARTITION_D_FLASH,0,DFPART,EEE_SECTORS,0,0,0);

    EEE_Int[0] = 0x6006;
    EEE_Int[0] = 0x1001;  // this shows that with the EEE disabled it is still possible!
    temp = EEE_Int[0];    // to write to the EEE-RAM region. However the value is volatile

// enable writes of EEE records 
    LaunchFlashCommand(1,ENABLE_EEPROM_EMULATION,0,0,0,0,0,0);
            
    EEE_Int[0] = 0x2002;  // update EEPROM and read it while the EEE system is active i.e. while the record is being updated 
    temp = EEE_Int[0];    // notice how the variable is stored in EEE-Flash (bottom Memory window)

    EEE_Int[0] = 0x1234;
    EEE_Int[0] = 0x5678;
    EEE_Int[0] = 0xABCD;
    EEE_Int[0] = 0x1111;
    EEE_Int[0] = 0x2222;
    EEE_Int[0] = 0x3333;
       
// turn off the EEE record writing 
    LaunchFlashCommand(1,DISABLE_EEPROM_EMULATION,0,0,0,0,0,0);

   
// can still read and write the EEE RAM 
    EEE_Int[0] = 0x3003;  // notice how the EEE-FLASH remains unaltered
    temp = EEE_Int[0];    // and read it 

    EEE_Int[0] = 0x4004;  // notice how the tag count (in the DATA1 window - expand the FTM) 
    temp = EEE_Int[0];    // remains at one: only one value has to be updated  and read it 
   
    EEE_Int[0] = 0x5005;  
    temp = EEE_Int[0];    

    EEE_Int[0] = 0x6006;
    temp = EEE_Int[0];    

    temp = FTM.etag;      // the tag counter should be 1 because only one record needs updating 


    EEE_Int[0]=0x0000;
    EEE_Int[1]=0x1111;
    EEE_Int[2]=0x2222;
    EEE_Int[3]=0x3333;
    EEE_Int[4]=0x4444;
    EEE_Int[5]=0x5555;
    EEE_Int[6]=0x6666;
    EEE_Int[7]=0x7777;
    temp = FTM.etag;      // the tag counter should be 8 because only one record needs updating 


// And now back up the data here enable writes of EEE records 
    LaunchFlashCommand(1,ENABLE_EEPROM_EMULATION,0,0,0,0,0,0);
    
    temp = FTM.etag;      // the tag counter should be 0 in single step debugger  
   
// wait for the EEE store to be completed 
    while(FTM.fstat.bit.mgbusy || FTM.etag ) {   // wait for EEE to write
    }  // notice: for EEE_int[0], only the final value (0x0000) is written to EEE_Flash 
       // as this is the latest value. The other changes can be ignored.

// disable the EEE 
    LaunchFlashCommand(1,DISABLE_EEPROM_EMULATION,0,0,0,0,0,0);
   
// and here we trash the EEE value to see what reset or power down does 
    EEE_Int[0] = 0xDEAD;
    temp = EEE_Int[0];     // and read it
   
    for(;;) { // now reset the part and reload this binary. The value at EEE_Int[0] should still be 0x6006 
    }
}


/******************************************************************************
Function Name	:	Error
Engineer		   :	r32151
Date			   :	02/05/06
Parameters		:	error code
Returns			:	NONE
Notes			   :	Flashes an error code on the LEDS
******************************************************************************/
void Error(unsigned char error_code)					
{
   while(1) {}
}

/******************************************************************************
Function Name	:	Delay
Engineer		   :	r32151
Date			   :	02/06/00
Parameters		:	unsigned int delayTime
Returns			:	NONE
Notes			   :	Simple software delay dependent on CPU clock frequency and
					   compile strategy 
******************************************************************************/
void 
Delay(unsigned int delayTime)					
{
   unsigned int x;						 /*outer loop counter */
  	char y;									 /*inner loop counter */

  	for (x=0; x<delayTime; x++)
  	{	
  		for (y=0; y<100; y++)
  		{} 
	}
}

/*****************************************************************************/
/********* interrupt SERVICE ROUTINES - Non-Maskable vectors shown ***********/
/*****************************************************************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED 

/******************************************************************************  
Function Name  : System_Call_ISR	  ===== non maskable
Engineer       : 	
Date           : 
Parameters     : NONE
Returns        : NONE
Notes          : 
******************************************************************************/
interrupt void System_Call_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************  
Function Name  : Spurious_ISR		  ===== non maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void Spurious_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************  
Function Name  : XGATE_Error_ISR	  ===== non maskable										
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void XGATE_Error_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
            /* clear the error flag */
   XGATE.xgmctl = XGSWEF | XGSWEFM;	
}

/******************************************************************************  
Function Name  : MPU_ISR			  ===== non maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void MPU_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
            /* clear the error flag */
   MPU.mpuflg.byte = AEF;
}

/******************************************************************************
Function Name  : CM_ISR			     ===== Clock Monitor Reset Vector
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void CM_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : COP_ISR		     ===== COP Watchdog Reset Vector
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void COP_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : Trap_ISR		     ===== non maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void Trap_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : SWI_ISR		     ===== non maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void SWI_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : XIRQ_ISR		     ===== X-bit maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for unused interrupt vectors. 
******************************************************************************/
interrupt void XIRQ_ISR(void) {
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : FTM_ERROR_ISR     ===== X-bit maskable
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for FTM related errors 
******************************************************************************/
interrupt void FTM_ERROR_ISR(void) {
   volatile tU08 ftmStat; /* local copy */
      /* Disable the EEE */
   ftmStat = LaunchFlashCommand(1 ,DISABLE_EEPROM_EMULATION, 0, 0, 0, 0, 0, 0);
   if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
      Error(ftmStat);
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
                /* halt if an EEE error interrupt ever occurs */
   while(1);
}

/******************************************************************************
Function Name  : LVI_ISR		     ===== Low Voltage Interrupt
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for low voltage interrupt 
******************************************************************************/
interrupt void LVI_ISR(void) {
   volatile tU08 ftmStat; /* local copy */
      /* Disable the EEE */
   ftmStat = LaunchFlashCommand(1 ,DISABLE_EEPROM_EMULATION, 0, 0, 0, 0, 0, 0);
   if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
      Error(ftmStat);
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : SCM_ISR		     ===== Self Clock Mode
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for Self Clock Mode
******************************************************************************/
interrupt void SCM_ISR(void) {
   volatile tU08 ftmStat; /* local copy */   
      /* Disable the EEE */
   ftmStat = LaunchFlashCommand(1 ,DISABLE_EEPROM_EMULATION, 0, 0, 0, 0, 0, 0);
   if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
      Error(ftmStat);
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}

/******************************************************************************
Function Name  : CRG_PLL		     ===== CRG PLL lock - if the part loses lock
Engineer       : r32151	
Date           : 06/05/2003
Parameters     : NONE
Returns        : NONE
Notes          : interrupt service routine for low voltage interrupt 
******************************************************************************/
interrupt void CRG_PLL(void) {
   volatile tU08 ftmStat; /* local copy */
      /* Disable the EEE */
   ftmStat = LaunchFlashCommand(1 ,DISABLE_EEPROM_EMULATION, 0, 0, 0, 0, 0, 0);
   if ((ftmStat & (ACCERR|FPVIOL|MGSTAT1|MGSTAT0)))
      Error(ftmStat);
   asm NOP;		 /* to avoid unintentional single stepping of BGND instruction */
   asm BGND;
}