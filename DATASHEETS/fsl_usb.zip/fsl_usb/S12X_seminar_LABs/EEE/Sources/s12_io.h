/******************************************************************************
													            Copyright (c) Freescale 2005
File Name	 :	$RCSfile: s12_io.h,v $

Engineer		 :	$Author: r32151 $

Location		 :	EKB

Date Created	  :	02/03/2005

Current Revision :	$Revision: 1.0 $

Notes            :  

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/

#ifndef S12_IO_H        /*prevent duplicated includes*/
#define S12_IO_H

/************************* function prototypes *******************************/
#pragma CODE_SEG DEFAULT
void ConfigurePorts(void);

/************************* #defines ******************************************/
#define ALL_FULL_DRIVE		0x00   
#define ALL_REDUCED_DRIVE	0xFF

#define ALL_PULLS_OFF		0x00
#define ALL_PULLS_ON	      0xFF

#define ALL_PULLED_UP		0x00   
#define ALL_PULLED_DOWN		0xFF

#define ALL_INPUTS			0x00
#define ALL_OUTPUTS			0xFF	

#define ALL_LOW				0x00
#define ALL_HIGH			   0xFF

/************************* Include Files *************************************/

/************************* typedefs ******************************************/

/************************* Global Variables **********************************//* Header file for IO configuration routine */


#endif /* S12_IO_H */
