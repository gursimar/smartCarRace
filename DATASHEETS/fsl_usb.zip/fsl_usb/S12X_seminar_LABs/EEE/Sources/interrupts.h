/******************************************************************************
                                                   COPYRIGHT (c) Freescale 2005  
                                                                          
File Name          :    $RCSfile: interrupts.h,v $                     
                                                                          
Current Revision :      $Revision: 1.1 $                                  
                                                                          
PURPOSE: header file defining all interrupts behaviour on HCS12XEP100.                         
                                                                          
DESCRIPTION:  Defines interrupt priority, service target and service routines 
              for all interrupt vectors on HCS12XEP100 on a vector by vector
              basis.
              Controls the XGATE freeze and fake activity behaviour and the 
              size of the memory allocated for the two XGATE stack regions.
                 
                                                                          
UPDATE HISTORY                                                            
REV  AUTHOR      DATE        DESCRIPTION OF CHANGE                        
---  ------      --------    ---------------------                        
1.0  r32151      12/10/05    Initial Revision.   
1.1  r32151      26/01/06    Changed XGATE stack initalisation from actual
                             addresses to stack size values in order to 
                             facilitate changing the XGATE memory map 
                             without having to explictly manage changes to 
                             the stack locations.

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/
#ifndef INTERRUPTS_H	/* prevent duplicated includes */
#define INTERRUPTS_H


/************************* configuration field settings **********************/
#define KEY0 0xFFFF
#define KEY1 0xFFFF
#define KEY2 0xFFFF
#define KEY3 0xFFFF


#define FOPT  0xFF
#define FPROT 0xFF
#define EPROT 0xFF
#define NVBYT 0xFF
#define FSEC  0xFE    /* don't change unless you want to secure!!!!! */

/************ copy any typedefs for XGate Parameters here *******************/





/************ copy extern declarations for XGate Parameters here ************/
#pragma DATA_SEG SHARED_DATA






/************ XGATE OPTIONS *************************************************/
/* XGate will be configured for :
   XGate enabled 
   Global enable for interrupts to CPU core enabled 
   Any pending interrupt flag cleared */

/*** Un/comment out either of these other options as required ***/
   #define XG_FREEZES        /* XGate freeze enabled  */
                             /* halts XGate activity in BDM active mode */					  

//   #define XG_FAKE_ACTIVITY  /* XGate fake activity enabled  */
                             /* With CPU stopped, clocks continue ouside */
                             /*  XGate thread */

/* XGate Priority Level - for all SIF XGate channel interrupt flags */ 
   #define _XGATE_PRI  						 LEVEL1

/**** XGATE Stack Initialisation ****/
   
   #define XGATE_LO_STACK_SIZE 0x40		/* words */
   #define XGATE_HI_STACK_SIZE 0x40		/* words */

/***************** interrupt settings ***************************************/

   #define CPU_VECTOR_BASE 0x3F /* 0x3F00 - 0x3FFF ; default is 0xFF, 0xFF00 - 0xFFFF*/


/************************* #defines ******************************************/
#define LEVEL0 PRIOLVL0
#define LEVEL1 PRIOLVL1 
#define LEVEL2 PRIOLVL2 
#define LEVEL3 PRIOLVL3 
#define LEVEL4 PRIOLVL4 
#define LEVEL5 PRIOLVL5 
#define LEVEL6 PRIOLVL6 
#define LEVEL7 PRIOLVL7 
#define XGATE_REQUEST RQST
#define CPU_REQUEST   0

/*** CPU ONLY ***/

/* Spurious  :: CPU Vector 0xFF10 :: NO XGate Channel  ***************************/
      /* CPU Service Vector      */
   #define _S12_VEC_10                  Spurious_ISR    

/* SYS :: CPU Vector 0xFF12 :: NO XGate Channel ******************************/
      /* CPU Service Vector      */
   #define _S12_VEC_12                  System_Call_ISR    

/* MPU Access error :: CPU Vector 0xFF14:: NO XGate Channel *****/
      /* CPU Service Vector      */
   #define _S12_VEC_14                  MPU_ISR    
  
/* XGATE error :: CPU Vector 0xFF16:: :: NO XGate Channel ****************/
      /* CPU Service Vector      */
   #define _S12_VEC_16                  XGATE_Error_ISR    

/* IRQ  :: CPU Vector 0xFFF2 :: NO XGate Channel *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_F2                  LEVEL1                
      /* CPU Service Vector      */
   #define _S12_VEC_F2                  Default_ISR    

/* XIRQ  :: CPU Vector 0xFFF4 :: NO XGate Channel  ***************************/
      /* CPU Service Vector      */
   #define _S12_VEC_F4                  XIRQ_ISR    

/* SWI :: CPU Vector 0xFFF6 :: NO XGate Channel ******************************/
      /* CPU Service Vector      */
   #define _S12_VEC_F6                  SWI_ISR    

/* Unallocated instruction trap :: CPU Vector 0xFFF8 :: NO XGate Channel *****/
      /* CPU Service Vector      */
   #define _S12_VEC_F8                  Trap_ISR    
  
/* COP failure reset :: CPU Vector 0xFFFA :: XGate Channel 3D ****************/
      /* CPU Service Vector      */
   #define _S12_VEC_FA                  COP_ISR    

/* Clock monitor fail reset :: CPU Vector 0xFFFC :: NO XGate Channel *********/
      /* CPU Service Vector      */
   #define _S12_VEC_FC                  CM_ISR    

/* Reset Vector :: CPU Vector 0xFFFE :: NO XGate Channel *********************/
      /* CPU Service Vector      */
   #define _S12_VEC_FE                  _Startup   



/*** ATD ***/
/* ATD0 :: CPU Vector 0xFFD2 :: XGate Channel 69 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_D2                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_D2                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_D2                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_69                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_69                   (xgdataptr)0x69  

/* ATD0 Compare :: CPU Vector 0xFF3E :: XGate Channel 1F ********************/
      /* Interrupt priority      */
   #define _INT_PRI_3E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_3E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_3E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_1F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_1F                   (xgdataptr)0x1F  

/* ATD1 :: CPU Vector 0xFFD0 :: XGate Channel 68 ****************************/
      /* Interrupt priority      */
   #define _INT_PRI_D0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_D0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_D0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_68                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_68                   (xgdataptr)0x68  

/* ATD1 Compare :: CPU Vector 0xFF3C :: XGate Channel 1E ********************/
      /* Interrupt priority      */
   #define _INT_PRI_3C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_3C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_3C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_1E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_1E                   (xgdataptr)0x1E  

/*** CRG ***/
/* CRG Self Clock Mode :: CPU Vector 0xFFC4 :: XGate Channel 62 *************/
      /* Interrupt priority      */
   #define _INT_PRI_C4                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_C4                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_C4                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_62                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_62                   (xgdataptr)0x62  

/* CRG PLL lock :: CPU Vector 0xFFC6 :: XGate Channel 63 ********************/
      /* Interrupt priority      */
   #define _INT_PRI_C6                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_C6                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_C6                  CRG_PLL    
      /* XGate Service Vector    */
   #define _XG_VEC_63                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_63                   (xgdataptr)0x63  

/*** ECT ***/
/* Enhanced Capture Timer channel 0 :: CPU Vector 0xFFEE :: XGate Channel 77 */
      /* Interrupt priority      */
   #define _INT_PRI_EE                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_EE                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_EE                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_77                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_77                   (xgdataptr)0x77  

/* Enhanced Capture Timer channel 1 :: CPU Vector 0xFFEC :: XGate Channel 76 */
      /* Interrupt priority      */
   #define _INT_PRI_EC                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_EC                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_EC                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_76                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_76                   (xgdataptr)0x76  

/* Enhanced Capture Timer channel 2 :: CPU Vector 0xFFEA :: XGate Channel 75 */
      /* Interrupt priority      */ 
   #define _INT_PRI_EA                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_EA                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_EA                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_75                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_75                   (xgdataptr)0x75  

/* Enhanced Capture Timer channel 3 :: CPU Vector 0xFFE8 :: XGate Channel 74 */
      /* Interrupt priority      */
   #define _INT_PRI_E8                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_E8                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_E8                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_74                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_74                   (xgdataptr)0x74  

/* Enhanced Capture Timer channel 4 :: CPU Vector 0xFFE6 :: XGate Channel 73 */
      /* Interrupt priority      */
   #define _INT_PRI_E6                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_E6                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_E6                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_73                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_73                   (xgdataptr)0x73  

/* Enhanced Capture Timer channel 5 :: CPU Vector 0xFFE4 :: XGate Channel 72 */
      /* Interrupt priority      */
   #define _INT_PRI_E4                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_E4                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_E4                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_72                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_72                   (xgdataptr)0x72  

/* Enhanced Capture Timer channel 6 :: CPU Vector 0xFFE2 :: XGate Channel 71 */
      /* Interrupt priority      */
   #define _INT_PRI_E2                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_E2                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_E2                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_71                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_71                   (xgdataptr)0x71  

/* Enhanced Capture Timer channel 7 :: CPU Vector 0xFFE0 :: XGate Channel 70 */
      /* Interrupt priority      */
   #define _INT_PRI_E0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_E0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_E0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_70                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_70                   (xgdataptr)0x70  

/* Enhanced Capture Timer Overflow :: CPU Vector 0xFFDE :: XGate Channel 6F **/
      /* Interrupt priority      */
   #define _INT_PRI_DE                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_DE                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_DE                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6F                   (xgdataptr)0x6F  

/* Modulus Down Counter Underflow :: CPU Vector 0xFFCA :: XGate Channel 65 ***/
      /* Interrupt priority      */
   #define _INT_PRI_CA                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_CA                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_CA                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_65                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_65                   (xgdataptr)0x65  

/* Pulse accumulator input edge :: CPU Vector 0xFFDA :: XGate Channel 6D *****/
      /* Interrupt priority      */
   #define _INT_PRI_DA                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_DA                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_DA                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6D                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6D                   (xgdataptr)0x6D  

/* Pulse accumulator A overflow  :: CPU Vector 0xFFDC :: XGate Channel 6E ****/
      /* Interrupt priority      */
   #define _INT_PRI_DC                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_DC                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_DC                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6E                   (xgdataptr)0x6E  

/* Pulse accumulator B overflow :: CPU Vector 0xFFC8 :: XGate Channel 64 *****/
      /* Interrupt priority      */
   #define _INT_PRI_C8                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_C8                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_C8                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_64                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_64                   (xgdataptr)0x64  

/*** FLASH and EEEPROM ***/
/* Flash :: CPU Vector 0xFFB8 :: XGate Channel 5C ****************************/
      /* Interrupt priority      */
   #define _INT_PRI_B8                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_B8                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_B8                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5C                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5C                   (xgdataptr)0x5C  

/* Flash error detect :: CPU Vector 0xFFBA :: XGate Channel 5D ***************/
      /* Interrupt priority      */
   #define _INT_PRI_BA                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_BA                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_BA                  FTM_ERROR_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5D                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5D                   (xgdataptr)0x5D  

/*** IIC ***/
/* IIC0 :: CPU Vector 0xFFC0 :: XGate Channel 60 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_C0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_C0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_C0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_60                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_60                   (xgdataptr)0x60  

/* IIC1 :: CPU Vector 0xFF82 :: XGate Channel 41 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_82                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_82                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_82                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_41                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_41                   (xgdataptr)0x41  

/*** MSCAN ***/
/* MSCAN 0 transmit :: CPU Vector 0xFFB0 :: XGate Channel 58 *****************/
      /* Interrupt priority      */
   #define _INT_PRI_B0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_B0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_B0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_58                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_58                   (xgdataptr)0x58  

/* MSCAN 0 receive :: CPU Vector 0xFFB2 :: XGate Channel 59 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_B2                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_B2                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_B2                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_59                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_59                   (xgdataptr)0x59  

/* MSCAN 0 errors :: CPU Vector 0xFFB4 :: XGate Channel 5A *******************/
      /* Interrupt priority      */
   #define _INT_PRI_B4                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_B4                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_B4                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5A                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5A                   (xgdataptr)0x5A  

/* MSCAN 0 wake-up :: CPU Vector 0xFFB6 :: XGate Channel 5B ******************/
      /* Interrupt priority      */
   #define _INT_PRI_B6                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_B6                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_B6                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5B                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5B                   (xgdataptr)0x5B  

/* MSCAN 1 transmit :: CPU Vector 0xFFA8 :: XGate Channel 54 *****************/
      /* Interrupt priority      */
   #define _INT_PRI_A8                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_A8                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_A8                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_54                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_54                   (xgdataptr)0x54  

/* MSCAN 1 receive :: CPU Vector 0xFFAA :: XGate Channel 55 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_AA                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_AA                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_AA                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_55                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_55                   (xgdataptr)0x55  

/* MSCAN 1 errors :: CPU Vector 0xFFAC :: XGate Channel 56 *******************/
      /* Interrupt priority      */
   #define _INT_PRI_AC                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_AC                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_AC                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_56                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_56                   (xgdataptr)0x56  

/* MSCAN 1 wake-up :: CPU Vector 0xFFAE :: XGate Channel 57 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_AE                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_AE                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_AE                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_57                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_57                   (xgdataptr)0x57  

/* MSCAN 2 transmit :: CPU Vector 0xFFA0 :: XGate Channel 50 *****************/
      /* Interrupt priority      */
   #define _INT_PRI_A0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_A0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_A0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_50                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_50                   (xgdataptr)0x50  

/* MSCAN 2 receive :: CPU Vector 0xFFA2 :: XGate Channel 51 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_A2                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_A2                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_A2                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_51                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_51                   (xgdataptr)0x51  

/* MSCAN 2 errors  :: CPU Vector 0xFFA4 :: XGate Channel 52 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_A4                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_A4                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_A4                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_52                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_52                   (xgdataptr)0x52  

/* MSCAN 2 wake-up :: CPU Vector 0xFFA6 :: XGate Channel 53 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_A6                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_A6                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_A6                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_53                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_53                   (xgdataptr)0x53  

/* MSCAN 3 transmit :: CPU Vector 0xFF98 :: XGate Channel 4C *****************/
      /* Interrupt priority      */
   #define _INT_PRI_98                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_98                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_98                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4C                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4C                   (xgdataptr)0x4C  

/* MSCAN 3 receive :: CPU Vector 0xFF9A :: XGate Channel 4D ******************/
      /* Interrupt priority      */
   #define _INT_PRI_9A                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_9A                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_9A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4D                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4D                   (xgdataptr)0x4D  

/* MSCAN 3 errors :: CPU Vector 0xFF9C :: XGate Channel 4E *******************/
      /* Interrupt priority      */
   #define _INT_PRI_9C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_9C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_9C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4E                   (xgdataptr)0x4E  

/* MSCAN 3 wake-up :: CPU Vector 0xFF9E :: XGate Channel 4F ******************/
      /* Interrupt priority      */
   #define _INT_PRI_9E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_9E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_9E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4F                   (xgdataptr)0x4F  

/* 0x90 MSCAN 4 transmit :: CPU Vector 0xFF90 :: XGate Channel 48 ************/
      /* Interrupt priority      */
   #define _INT_PRI_90                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_90                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_90                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_48                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_48                   (xgdataptr)0x48  

/* MSCAN 4 receive :: CPU Vector 0xFF92 :: XGate Channel 49 ******************/
      /* Interrupt priority      */
   #define _INT_PRI_92                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_92                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_92                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_49                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_49                   (xgdataptr)0x49  

/* MSCAN 4 errors :: CPU Vector 0xFF94 :: XGate Channel 4A *******************/
      /* Interrupt priority      */
   #define _INT_PRI_94                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_94                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_94                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4A                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4A                   (xgdataptr)0x4A  

/* MSCAN 4 wake-up  :: CPU Vector 0xFF96 :: XGate Channel 4B *****************/
      /* Interrupt priority      */
   #define _INT_PRI_96                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_96                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_96                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_4B                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_4B                   (xgdataptr)0x4B  

/*** PIM Key Wakeup Ports ***/
/* Port H :: CPU Vector 0xFFCC :: XGate Channel 66 ***************************/
      /* Interrupt priority      */
   #define _INT_PRI_CC                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_CC                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_CC                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_66                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_66                   (xgdataptr)0x66  

/* Port J :: CPU Vector 0xFFCE :: XGate Channel 67 ***************************/
      /* Interrupt priority      */
   #define _INT_PRI_CE                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_CE                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_CE                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_67                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_67                   (xgdataptr)0x67  

/* Port P Interrupt :: CPU Vector 0xFF8E :: XGate Channel 47 *****************/
      /* Interrupt priority      */
   #define _INT_PRI_8E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_8E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_8E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_47                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_47                   (xgdataptr)0x47  

/*** PIT ***/
/* Periodic Interrupt Timer 0 :: CPU Vector 0xFF7A :: XGate Channel 3D *******/
      /* Interrupt priority      */
   #define _INT_PRI_7A                  LEVEL3                
      /* Interrupt Service Owner */
   #define _INT_SER_7A                  XGATE_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_7A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3D                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3D                   (xgdataptr)0x3D  

/* Periodic Interrupt Timer 1 :: CPU Vector 0xFF78 :: XGate Channel 3C *******/
      /* Interrupt priority      */
   #define _INT_PRI_78                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_78                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_78                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3C                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3C                   (xgdataptr)0x3C  

/* Periodic Interrupt Timer 2 :: CPU Vector 0xFF76 :: XGate Channel 3B *******/
      /* Interrupt priority      */
   #define _INT_PRI_76                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_76                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_76                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3B                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3B                   (xgdataptr)0x3B  

/* Periodic Interrupt Timer 3 :: CPU Vector 0xFF74 :: XGate Channel 3A *******/
      /* Interrupt priority      */
   #define _INT_PRI_74                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_74                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_74                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3A                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3A                   (xgdataptr)0x3A  

/* Periodic Interrupt Timer 4 :: CPU Vector 0xFF5E :: XGate Channel 2F *******/
      /* Interrupt priority      */
   #define _INT_PRI_5E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_5E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_5E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2F                   (xgdataptr)0x2F  

/* Periodic Interrupt Timer 5 :: CPU Vector 0xFF5C :: XGate Channel 2E *******/
      /* Interrupt priority      */
   #define _INT_PRI_5C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_5C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_5C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2E                   (xgdataptr)0x2E  

/* Periodic Interrupt Timer 6 :: CPU Vector 0xFF5A :: XGate Channel 2D *******/
      /* Interrupt priority      */
   #define _INT_PRI_5A                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_5A                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_5A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2D                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2D                   (xgdataptr)0x2D  

/* Periodic Interrupt Timer 7 :: CPU Vector 0xFF58 :: XGate Channel 2C *******/
      /* Interrupt priority      */
   #define _INT_PRI_58                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_58                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_58                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2C                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2C                   (xgdataptr)0x2C  


/*** PWM ***/
/* PWM Emergency Shutdown :: CPU Vector 0xFF8C :: XGate Channel 46 ***********/
      /* Interrupt priority      */
   #define _INT_PRI_8C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_8C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_8C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_46                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_46                   (xgdataptr)0x46  

/*** RTI ***/
/* Real Time Interrupt :: CPU Vector 0xFFF0 :: XGate Channel 78 **************/
      /* Interrupt priority      */
   #define _INT_PRI_F0                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_F0                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_F0                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_78                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_78                   (xgdataptr)0x78  

/*** SCI ***/
/* SCI0 :: CPU Vector 0xFFD6 :: XGate Channel 6B *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_D6                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_D6                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_D6                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6B                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6B                   (xgdataptr)0x6B  

/* SCI1 :: CPU Vector 0xFFD4 :: XGate Channel 6A *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_D4                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_D4                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_D4                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6A                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6A                   (xgdataptr)0x6A  

/* SCI2 :: CPU Vector 0xFF8A :: XGate Channel 45 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_8A                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_8A                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_8A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_45                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_45                   (xgdataptr)0x45  

/* SCI3 :: CPU Vector 0xFF88 :: XGate Channel 44 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_88                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_88                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_88                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_44                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_44                   (xgdataptr)0x44  

/* SCI4 :: CPU Vector 0xFF86 :: XGate Channel 43 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_86                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_86                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_86                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_43                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_43                   (xgdataptr)0x43  

/* SCI5 :: CPU Vector 0xFF84 :: XGate Channel 42 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_84                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_84                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_84                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_42                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_42                   (xgdataptr)0x42  

/* SCI6 :: CPU Vector 0xFFC2 :: XGate Channel 61 *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_C2                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_C2                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_C2                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_61                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_61                   (xgdataptr)0x61  

/* SCI7 :: CPU Vector 0xFF56 :: XGate Channel 2B *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_56                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_56                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_56                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2B                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2B                   (xgdataptr)0x2B  

/*** SPI ***/
/* SPI0 :: CPU Vector 0xFFD8 :: XGate Channel 6C *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_D8                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_D8                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_D8                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_6C                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_6C                   (xgdataptr)0x6C  

/* SPI1 :: CPU Vector 0xFFBE :: XGate Channel 5F *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_BE                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_BE                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_BE                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5F                   (xgdataptr)0x5F  

/* SPI2 :: CPU Vector 0xFFBC :: XGate Channel 5E *****************************/
      /* Interrupt priority      */
   #define _INT_PRI_BC                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_BC                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_BC                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_5E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_5E                   (xgdataptr)0x5E  

/*** TIM - Standard Timer ***/
/* Standard Timer channel 0 :: CPU Vector 0xFF54 :: XGate Channel 2A */
      /* Interrupt priority      */
   #define _INT_PRI_54                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_54                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_54                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_2A                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_2A                   (xgdataptr)0x2A  

/* Standard Timer channel 1 :: CPU Vector 0xFF52 :: XGate Channel 29 */
      /* Interrupt priority      */
   #define _INT_PRI_52                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_52                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_52                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_29                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_29                   (xgdataptr)0x29  

/* Standard Timer channel 2 :: CPU Vector 0xFF50 :: XGate Channel 28 */
      /* Interrupt priority      */ 
   #define _INT_PRI_50                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_50                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_50                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_28                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_28                   (xgdataptr)0x28  

/* Standard Timer channel 3 :: CPU Vector 0xFF4E :: XGate Channel 27 */
      /* Interrupt priority      */
   #define _INT_PRI_4E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_4E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_4E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_27                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_27                   (xgdataptr)0x27  

/* Standard Timer channel 4 :: CPU Vector 0xFF4C :: XGate Channel 26 */
      /* Interrupt priority      */
   #define _INT_PRI_4C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_4C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_4C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_26                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_26                   (xgdataptr)0x26  

/* Standard Timer channel 5 :: CPU Vector 0xFF4A :: XGate Channel 25 */
      /* Interrupt priority      */
   #define _INT_PRI_4A                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_4A                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_4A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_25                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_25                   (xgdataptr)0x25  

/* Standard Timer channel 6 :: CPU Vector 0xFF48 :: XGate Channel 24 */
      /* Interrupt priority      */
   #define _INT_PRI_48                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_48                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_48                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_24                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_24                   (xgdataptr)0x24  

/* Standard Timer channel 7 :: CPU Vector 0xFF46 :: XGate Channel 23 */
      /* Interrupt priority      */
   #define _INT_PRI_46                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_46                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_46                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_23                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_23                   (xgdataptr)0x23  

/* Standard Timer Overflow :: CPU Vector 0xFF44 :: XGate Channel 22 **/
      /* Interrupt priority      */
   #define _INT_PRI_44                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_44                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_44                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_22                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_22                   (xgdataptr)0x22  

/* Pulse accumulator A overflow  :: CPU Vector 0xFF42 :: XGate Channel 21 ****/
      /* Interrupt priority      */
   #define _INT_PRI_42                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_42                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_42                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_21                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_21                   (xgdataptr)0x21  

/* Pulse accumulator input edge :: CPU Vector 0xFF40 :: XGate Channel 20 *****/
      /* Interrupt priority      */
   #define _INT_PRI_40                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_40                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_40                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_20                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_20                   (xgdataptr)0x20  

/*** VREG ***/
/* API Autonomous Periodical Interrupt :: CPU Vector 0xFF7E :: XGate Channel 3F */
      /* Interrupt priority      */
   #define _INT_PRI_7E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_7E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_7E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3F                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3F                   (xgdataptr)0x3F  

/* LVI Low Voltage Interrupt :: CPU Vector 0xFF80 :: XGate Channel 40 ********/
      /* Interrupt priority      */
   #define _INT_PRI_80                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_80                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_80                  LVI_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_40                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_40                   (xgdataptr)0x40  

/*** XGATE ***/
/* XGATE Software Trigger 0 :: CPU Vector 0xFF72 :: XGate Channel 39 *********/
      /* Interrupt priority      */
   #define _INT_PRI_72                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_72                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_72                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_39                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_39                   (xgdataptr)0x39  

/* XGATE Software Trigger 1 :: CPU Vector 0xFF70 :: XGate Channel 38 *********/
      /* Interrupt priority      */
   #define _INT_PRI_70                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_70                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_70                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_38                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_38                   (xgdataptr)0x38  

/* XGATE Software Trigger 2 :: CPU Vector 0xFF6E :: XGate Channel 37 *********/
      /* Interrupt priority      */
   #define _INT_PRI_6E                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_6E                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_6E                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_37                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_37                   (xgdataptr)0x37  

/* XGATE Software Trigger 3 :: CPU Vector 0xFF6C :: XGate Channel 36 *********/
      /* Interrupt priority      */
   #define _INT_PRI_6C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_6C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_6C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_36                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_36                   (xgdataptr)0x36  

/* XGATE Software Trigger 4 :: CPU Vector 0xFF6A :: XGate Channel 35 *********/
      /* Interrupt priority      */
   #define _INT_PRI_6A                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_6A                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_6A                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_35                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_35                   (xgdataptr)0x35  

/* XGATE Software Trigger 5 :: CPU Vector 0xFF68 :: XGate Channel 34 *********/
      /* Interrupt priority      */
   #define _INT_PRI_68                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_68                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_68                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_34                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_34                   (xgdataptr)0x34  

/* XGATE Software Trigger 6 :: CPU Vector 0xFF66 :: XGate Channel 33 *********/
      /* Interrupt priority      */
   #define _INT_PRI_66                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_66                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_66                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_33                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_33                   (xgdataptr)0x33  

/* XGATE Software Trigger 7 :: CPU Vector 0xFF64 :: XGate Channel 32 *********/
      /* Interrupt priority      */
   #define _INT_PRI_64                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_64                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_64                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_32                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_32                   (xgdataptr)0x32  


/*** RESERVED ***/
/* Reserved :: CPU Vector 0xFF7C :: XGate Channel 3E *************************/
      /* Interrupt priority      */
   #define _INT_PRI_7C                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_7C                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_7C                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_3E                   Default_XSR            
      /* XGate Service Parameter */
   #define _XG_PRM_3E                   (xgdataptr)0x3E
    
/* Reserved :: CPU vector 0xFF60 :: XGate Channel 30 *************************/
   /* Interrupt priority      */
   #define _INT_PRI_60                  LEVEL1                
   /* Interrupt Service Owner */
   #define _INT_SER_60                  CPU_REQUEST           
   /* CPU Service Vector      */
   #define _S12_VEC_60                  Default_ISR        
   /* XGate Service Vector    */
   #define _XG_VEC_30                   Default_XSR             
   /* XGate Service Parameter */
   #define _XG_PRM_30                   (xgdataptr)0x30

/* Reserved :: CPU Vector 0xFF62 :: XGate Channel 31 *************************/
      /* Interrupt priority      */
   #define _INT_PRI_62                  LEVEL1                
      /* Interrupt Service Owner */
   #define _INT_SER_62                  CPU_REQUEST           
      /* CPU Service Vector      */
   #define _S12_VEC_62                  Default_ISR    
      /* XGate Service Vector    */
   #define _XG_VEC_31                   Default_XSR       
      /* XGate Service Parameter */
   #define _XG_PRM_31                   (xgdataptr)0x31  


#endif /* INTERRUPTS_H */

