/******************************************************************************
													            Copyright (c) Freescale 2006
File Name    : $RCSfile: main.h,v $

Current Revision :	$Revision: 1.0 $

PURPOSE: main program entry.                       
                                                                          
DESCRIPTION:  header file for main.c                                            
                                                                          
UPDATE HISTORY                                                            
REV  AUTHOR    DATE        DESCRIPTION OF CHANGE                          
---  ------    --------    ---------------------                          
1.0  r32151    01/03/05    - initial coding              

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

                                                                          
******************************************************************************/
/*===========================================================================*/
/* Freescale reserves the right to make changes without further notice to any*/
/* product herein to improve reliability, function, or design. Freescale does*/
/* not assume any  liability arising  out  of the  application or use of any */
/* product,  circuit, or software described herein;  neither  does it convey */
/* any license under its patent rights  nor the  rights of others.  Freescale*/
/* products are not designed, intended,  or authorized for use as components */
/* in  systems  intended  for  surgical  implant  into  the  body, or  other */
/* applications intended to support life, or  for any  other application  in */
/* which the failure of the Freescale product  could create a situation where*/
/* personal injury or death may occur. Should Buyer purchase or use Freescale*/
/* products for any such intended  or unauthorized  application, Buyer shall */
/* indemnify and  hold  Freescale  and its officers, employees, subsidiaries,*/
/* affiliates,  and distributors harmless against all claims costs, damages, */
/* and expenses, and reasonable  attorney  fees arising  out of, directly or */
/* indirectly,  any claim of personal injury  or death  associated with such */
/* unintended or unauthorized use, even if such claim alleges that  Freescale*/
/* was negligent regarding the  design  or manufacture of the part. Freescale*/
/* and the Freescale logo* are registered trademarks of Freescale Ltd.       */
/*****************************************************************************/
#ifndef MAIN_H       
#define MAIN_H

/************************* typedefs ******************************************/
/* Note: word / long elements of stuctures for access by XGate should have   */
/* even size i.e. on even boundary and all XGate pointers are 16-bit.        */

/************************* #defines ******************************************/

#define FCLK_DIV 4    /* flash clock divider for 4MHz crystal */

#define SystemCall asm sys

#define __SEG_START_REF(a)  __SEG_START_ ## a
#define __SEG_END_REF(a)    __SEG_END_   ## a
#define __SEG_SIZE_REF(a)   __SEG_SIZE_  ## a

#define __SEG_START_DEF(a)  extern char __SEG_START_REF(a) []
#define __SEG_END_DEF(a)    extern char __SEG_END_REF(  a) []
#define __SEG_SIZE_DEF(a)   extern char __SEG_SIZE_REF( a) []

/* define the symbols to be used: */
//  __SEG_START_DEF(SYSTEM_DATA); // start of system parameter variables
//  __SEG_END_DEF(SYSTEM_DATA);   // end of system parameter variables
//  __SEG_SIZE_DEF(SYSTEM_DATA);  // size of system parameter variables


/************************* Global Variables **********************************/
#pragma DATA_SEG SHARED_DATA

#pragma DATA_SEG DEFAULT

/************************* function prototypes *******************************/
#pragma CODE_SEG __NEAR_SEG NON_BANKED 

#pragma CODE_SEG DEFAULT
void main(void);
void Delay(unsigned int delayTime);
void Error(unsigned char error_code);					

#endif /* MAIN_H */  