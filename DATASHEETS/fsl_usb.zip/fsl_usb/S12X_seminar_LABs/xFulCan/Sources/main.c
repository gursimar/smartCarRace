/******************************************************************************
Copyright (c) Freescale Semiconductor 2005
File Name		 :	$RCSfile: main.c,v $
Engineer		 :	$Author: ttz778 $
Location		 :	EKB
Date Created	 :	23/02/2004
Current Revision :	$Revision: 1.2 $
Notes            :  
*******************************************************************************/

#include "per_XDx512_L15Y.h"
#include "xgCAN_drv.h"
#include "xgate_vectors.h"
#include "stdio.h"



#define REFDV 15					/* 16 MHz crystal */
#define SW1   (PTP.bit.bit0)
#define SW2   (PTP.bit.bit1)
#define Button_SW1   (tU08)15
#define Button_SW2   (tU08)16 
#define PRESS        (tU08)0   


/******************************************************************************
Function Name	:	PLLStartup
Engineer		:	r27624
Date			:	26/9/2001
Arguments		:	freq: 
Return			:	
Notes			:	Ref Clock is assumed to be 1MHz
******************************************************************************/
void PLLStartup(tU08 freq) 
{
									/* switch to OSCCLK */
	CRG.clksel.byte = 0;

 	CRG.pllctl.byte = CME   |		/* clock monitor enabled */
  	                PLLON |		/* PLL on */
	                  AUTO	|		/* automatic bandwidth control enabled */
		                SCME;			/* self clock mode enabled */
	
	if(freq != 0) 
	{
	  								/* configure PLL */
									/* fref = fosc / (REFDV+1) */
  		CRG.refdv.byte = REFDV;
									/* fvco = 2*fref*(SYNR+1) */
  		CRG.synr.byte = freq - 1;
									/* wait for lock FOR EVER! */
  		while(CRG.crgflg.bit.lock != 1) 
  		{
  		}
	  	if(CRG.crgflg.bit.lock == 1) 
	  	{
									/* switch to PLLCLK */
	    	CRG.clksel.byte |= PLLSEL;
  		}
	}
}

/******************************************************************************
Function Name	:	XGATE_Init
Engineer		:	r27624	
Date			:	24/02/2004
Parameters		:	None
Returns			:	None
Notes			:	
******************************************************************************/
void XGATE_Init(void) 
{
#ifdef __MWERKS__
                                               /* initialise XGATE vector base */
	XGATE.xgvbr = (int)((void*__far)XGATEVectorTable)-0x00c0;	
#else	 /* Cosmic */
                                               /* initialise XGATE vector base */
	XGATE.xgvbr = (int)XGATEVectorTable-0x00c0;	
#endif
                  /* interrupt enable, enable XGATE, stop XGATE in freeze mode */
	XGATE.xgmctl = 0xFBC1; /* XGE | XGFRZ | XGIE;	 */
}

/******************************************************************************
Function Name	:	SetIntPrio
Engineer		:	r27624	
Date			:	24/02/2004
Parameters		:	None
Returns			:	None
Notes			:	channel is equal to lower byte of CPU vector address / 2
******************************************************************************/
void SetIntPrio(char channel, char prio)	
{
	Interrupt.int_cfaddr = (channel << 1) & 0xf0;
	Interrupt.int_cfdata[channel & 0x07].byte = prio;
}

/******************************************************************************
Function Name	:	GetIntPrio
Engineer		:	r54430	
Date			:	24/03/2004
Parameters		:	None
Returns			:	None
Notes			:	channel is equal to lower byte of vector address 
                    i.e. Reset is channel 0xFE, SCI0 is channel 0xD6, etc. 
******************************************************************************/
char GetIntPrio(char channel)	
{
	Interrupt.int_cfaddr = (channel << 1) & 0xf0;
	return(Interrupt.int_cfdata[channel & 0x07].byte);
}

/******************************************************************************
Function Name	:	Int_Init
Engineer		:	r27624	
Date			:	24/02/2004
Parameters		:	None
Returns			:	None
Notes			:	 
******************************************************************************/
void Int_Init(void) 
{
#ifdef USE_CAN0
  SetIntPrio(CAN0RX_CHANNEL, RQST|2);	/* assign CAN0 Receive to XGATE, priority 2 */
	SetIntPrio(CAN0TX_CHANNEL, RQST|2);	/* assign CAN0 Transmit to XGATE, priority 2 */
#endif
#ifdef USE_CAN1
	SetIntPrio(CAN1RX_CHANNEL, RQST|2);	/* assign CAN1 Receive to XGATE, priority 2 */
	SetIntPrio(CAN1TX_CHANNEL, RQST|2);	/* assign CAN1 Transmit to XGATE, priority 2 */
#endif
#ifdef USE_CAN2
	SetIntPrio(CAN2RX_CHANNEL, RQST|2);	/* assign CAN2 Receive to XGATE, priority 2 */
	SetIntPrio(CAN2TX_CHANNEL, RQST|2);	/* assign CAN2 Transmit to XGATE, priority 2 */
#endif
#ifdef USE_CAN3
	SetIntPrio(CAN3RX_CHANNEL, RQST|2);	/* assign CAN3 Receive to XGATE, priority 2 */
	SetIntPrio(CAN3TX_CHANNEL, RQST|2);	/* assign CAN3 Transmit to XGATE, priority 2 */
#endif
#ifdef USE_CAN4
	SetIntPrio(CAN4RX_CHANNEL, RQST|2);	/* assign CAN4 Receive to XGATE, priority 2 */
	SetIntPrio(CAN4TX_CHANNEL, RQST|2);	/* assign CAN4 Transmit to XGATE, priority 2 */
#endif

	_asm("CLI");												/* clear interrupt mask bit */
}


void delay(unsigned long cnt) 
{   unsigned long i,j;

    for(j=0;j<cnt;j++) {
        for(i=0;i<500;i++);
    }
}

void LedDisp(tU08 n) 
{
    DDRA.byte = 0x0F;
    PORTA.byte = n&0x0F;
}

#define SCI0BD    *(unsigned int *)0x00C8
#define SCI0CR2   *(unsigned char *)0x00CB
#define SCI0SR1   *(unsigned char *)0x00CC
#define SCI0DRL   *(unsigned char *)0x00CF

void InitSCI0(void) 
{
/* baudrate = busfreq/sci0bd/16 */
    SCI0BD = 65;      // baudrate = 9600
    SCI0CR2 =0x08;
}

void TERMIO_PutChar(char C) 
{
    while((SCI0SR1&0x80)!=0x80);
    SCI0DRL=C;
}


/******************************************************************************
Function Name	:	main
Engineer		:	  r66193	
Date			:	    13/02/2007
Parameters		:	None
Returns			:	None
Notes			:	 
******************************************************************************/

void main (void) 
{   
  int ct=0;
  tU08 cnt=1;

	tU08 box_0;

	tU08 TxData_0[] = {7,6,5,4,3,2,1,0};

//	tU08 TxData_0[] = {0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55};
	tU08 TxLength_0 = 8;

	tU08 RxData_0[8];
	tU08 RxLength_0;
	
	tU08 Button;


	Int_Init();

	XGATE_Init();
	
	InitCAN(&ChannelCAN0,&CAN_Init_CAN0);


	for(;;) {
// if there is a active button, then send it
    if((SW1==PRESS)||(SW2==PRESS)) {
      if(SW1==PRESS) {
          Button=Button_SW1;
      }
      else if(SW2==PRESS) {
          Button=Button_SW2;
      }
      
      TxData_0[0]=Button;
  	  WriteCANMsg(&ChannelCAN0, CAN0_BOX19, &TxLength_0, TxData_0);
			SendCANMsg(&ChannelCAN0, CAN0_BOX19);
    }

// if there is a new message, then display the first byte.
		if((box_0 = FindNewCANMsg(&ChannelCAN0)) != NONEWCANMSG) {
			ReadCANMsg(&ChannelCAN0, box_0, &RxLength_0, RxData_0);
		  if(RxData_0[0]==Button_SW1) {
        LedDisp(0x05);
		  }
		  else if(RxData_0[0]==Button_SW2) {
        LedDisp(0x0A);
		  }
		}

	}
}


