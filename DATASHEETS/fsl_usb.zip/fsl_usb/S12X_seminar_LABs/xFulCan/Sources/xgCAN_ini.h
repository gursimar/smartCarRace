/******************************************************************************
Copyright (c) Freescale Semiconductor 2005
File Name		 :	$RCSfile: xgCAN_ini.h,v $
Engineer		 :	$Author: ttz778 $
Location		 :	EKB
Date Created :	01/04/2004
Current Revision :	$Revision: 1.3 $
Notes            :  This is only file that user need to modified.
******************************************************************************/
#include "per_XDx512_L15Y.h"

#define CAN_RECEIVE_NOTIFICATION  /* to enable CAN RX interrupt for notification */

/* define CANBENCH to measure XGATE execution time */
/*****************************************************************************
 CAN0
******************************************************************************/
#define USE_CAN0							    /* Define if this channel is used */

/* Hardware initialisation */
#define CANCTL0_CAN0  0x00		    /* clocked in Wait mode, timer disabled, wake-up disabled */
//#define CANCTL1_CAN0  CANE|LOOPB  /* for test: MSCAN enabled, clock = OSC_CLK, loop back enabled, listen only disabled, wake-up filter disabled */
#define CANCTL1_CAN0  CANE      /* for test: MSCAN enabled, clock = OSC_CLK, loop back disabled, listen only disabled, wake-up filter disabled */


#define CANBTR0_CAN0  0x43		    // SJW = 1,  prescaler = 4 
#define CANBTR1_CAN0  0x14		    // SAMP = 0, TSEG2 = 2, TSEG1 = 5, 8 Tq per bit 
#define CANRIER_CAN0  RXFIE 	    // receiver buffer full interrupt enable 
#define CANTIER_CAN0  0			      // transmit buffer empty interrupts disabled 


/*
#define CANBTR0_CAN0  0x47		    // SJW = 1,  prescaler = 8 
#define CANBTR1_CAN0  0x94		    // SAMP = 0, TSEG2 = 2, TSEG1 = 5, 8 Tq per bit 
#define CANRIER_CAN0  RXFIE 	    // receiver buffer full interrupt enable 
#define CANTIER_CAN0  0			      // transmit buffer empty interrupts disabled 
*/


#define CANIDAC_CAN0  IDAM0		    /* 4 x 16-bit filters */
#define CANIDAR0_CAN0 0
#define CANIDAR1_CAN0 (0x100<<5)	/* compare all bits */

//#define CANIDMR0_CAN0 0xFFFFFFFF	/* mask all bits */
//#define CANIDMR1_CAN0 0xFFFFFFFF	/* mask all bits */
#define CANIDMR0_CAN0 0x00000000	/* compare all bits */
#define CANIDMR1_CAN0 0x00000000	/* compare all bits */

/* Mailbox initialisation */
#define RXBOXSIZE_CAN0  16			  /* number of receive mailboxes, limited to max 16 by RxStatus size */
#define TXBOXSIZE_CAN0  4         /* number of transmit mailboxes, limited to max 16 by TxStatus size */

/* define (RXBOXSIZE_CAN0 - 1) receive identifiers, least frequent first */
#define CAN0ID1 		0x700
#define CAN0ID2 		0x555
#define CAN0ID3 		0x2AA
#define CAN0ID4 		0x10F
#define CAN0ID5 		0x10E
#define CAN0ID6 		0x10D
#define CAN0ID7 		0x10C
#define CAN0ID8 		0x10B
#define CAN0ID9 		0x10A
#define CAN0ID10		0x109
#define CAN0ID11		0x108 
#define CAN0ID12 		0x107
#define CAN0ID13 		0x106
#define CAN0ID14 		0x105
#define CAN0ID15 		0x104

/* define TXBOXSIZE_CAN0 transmit identifiers */
#define CAN0ID16 		0x2AA
#define CAN0ID17 		0x104
#define CAN0ID18 		0x101
#define CAN0ID19 		0x100

/* optionally, define a handle for each mailbox as well */
#define CAN0_BOX17  17
#define CAN0_BOX19  19
  

