/******************************************************************************
Copyright (c) Freescale Semiconductor 2005
File Name		 :	$RCSfile: xgcan_drv.c,v $
Engineer		 :	$Author: ttz778 $
Location		 :	EKB
Date Created	 :	29/04/2004
Current Revision :	$Revision: 1.1 $
Notes            :  
******************************************************************************/
#include "xgCAN_drv.h"

#ifdef USE_CAN0

tU16 ID_Table_CAN0[] = {0 				
#if(BOXSIZE_CAN0 > 1)  
                       ,CAN_SID(CAN0ID1)			 
#if(BOXSIZE_CAN0 > 2)                     
                       ,CAN_SID(CAN0ID2)
#if(BOXSIZE_CAN0 > 3)                     
                       ,CAN_SID(CAN0ID3)
#if(BOXSIZE_CAN0 > 4)                     
                       ,CAN_SID(CAN0ID4)
#if(BOXSIZE_CAN0 > 5)                     
                       ,CAN_SID(CAN0ID5)
#if(BOXSIZE_CAN0 > 6)                     
                       ,CAN_SID(CAN0ID6)
#if(BOXSIZE_CAN0 > 7)                     
                       ,CAN_SID(CAN0ID7)
#if(BOXSIZE_CAN0 > 8)                     
                       ,CAN_SID(CAN0ID8)
#if(BOXSIZE_CAN0 > 9)                     
                       ,CAN_SID(CAN0ID9)
#if(BOXSIZE_CAN0 > 10)                     
                       ,CAN_SID(CAN0ID10)
#if(BOXSIZE_CAN0 > 11)                     
                       ,CAN_SID(CAN0ID11)
#if(BOXSIZE_CAN0 > 12)                     
                       ,CAN_SID(CAN0ID12)
#if(BOXSIZE_CAN0 > 13)                     
                       ,CAN_SID(CAN0ID13)
#if(BOXSIZE_CAN0 > 14)                     
                       ,CAN_SID(CAN0ID14)
#if(BOXSIZE_CAN0 > 15)                     
                       ,CAN_SID(CAN0ID15)
#if(BOXSIZE_CAN0 > 16)                     
                       ,CAN_SID(CAN0ID16)
#if(BOXSIZE_CAN0 > 17)                     
                       ,CAN_SID(CAN0ID17)
#if(BOXSIZE_CAN0 > 18)                     
                       ,CAN_SID(CAN0ID18)
#if(BOXSIZE_CAN0 > 19)                    
                       ,CAN_SID(CAN0ID19)
#if(BOXSIZE_CAN0 > 20)                     
                       ,CAN_SID(CAN0ID20)
#if(BOXSIZE_CAN0 > 21)                     
                       ,CAN_SID(CAN0ID21)
#if(BOXSIZE_CAN0 > 22)                     
                       ,CAN_SID(CAN0ID22)
#if(BOXSIZE_CAN0 > 23)                     
                       ,CAN_SID(CAN0ID23)
#if(BOXSIZE_CAN0 > 24)                     
                       ,CAN_SID(CAN0ID24)
#if(BOXSIZE_CAN0 > 25)                     
                       ,CAN_SID(CAN0ID25)
#if(BOXSIZE_CAN0 > 26)                     
                       ,CAN_SID(CAN0ID26)
#if(BOXSIZE_CAN0 > 27)                     
                       ,CAN_SID(CAN0ID27)
#if(BOXSIZE_CAN0 > 28)                     
                       ,CAN_SID(CAN0ID28)
#if(BOXSIZE_CAN0 > 29)                     
                       ,CAN_SID(CAN0ID29)
#if(BOXSIZE_CAN0 > 30)                     
                       ,CAN_SID(CAN0ID30)
#if(BOXSIZE_CAN0 > 31)                     
                       ,CAN_SID(CAN0ID31)
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
                       };

tU08 MsgData_CAN0[BOXSIZE_CAN0][MSGLENGTH];
tU08 MsgLen_CAN0[BOXSIZE_CAN0];

tU16 RxStatus_CAN0 = 0;
tU16 TxStatus_CAN0 = 0;

const XGCANstruct ChannelCAN0 = {&CAN0
                                ,ID_Table_CAN0		
                                ,MsgData_CAN0
                                ,MsgLen_CAN0
                                ,&RxStatus_CAN0	
                                ,&TxStatus_CAN0
                                ,RXBOXSIZE_CAN0};

CAN_Init_Struct CAN_Init_CAN0 = {CANCTL0_CAN0 
                                ,CANCTL1_CAN0	
                                ,CANBTR0_CAN0 
                                ,CANBTR1_CAN0
                                ,CANRIER_CAN0 
                                ,CANTIER_CAN0 
                                ,CANIDAC_CAN0
                                ,CANIDAR0_CAN0
                                ,CANIDMR0_CAN0
                                ,CANIDAR1_CAN0
                                ,CANIDMR1_CAN0};

#endif /* USE_CAN0 */

/******************************************************************************
Function Name	:	InitCAN
Engineer		:	r27624	
Date			 :	11/03/2004
Parameters :  channel - pointer to structure containing MSCAN address
              CAN_Init - pointer to structure containing initialisation data
Returns		 :	None
Notes			 :  Initialises the MSCAN module with values contained in the structure 
              pointed to by CAN_Init. The initialisation values are statically 
              defined in xgCAN_ini.h. This routine must be called after reset 
              and before any CAN messages are transmitted or received.
******************************************************************************/
void InitCAN(const XGCANstruct *channel, CAN_Init_Struct *CAN_Init) 
{
	channel->pCAN->canctl0.byte = INITRQ; /* set INITRQ: put MSCAN in initialization mode */
	while(channel->pCAN->canctl1.bit.initak != 1); /* wait for INITAK to set: the MSCAN has entered into initialization mode */
										
	channel->pCAN->canctl1.byte = CAN_Init->canctl1.byte; /* control reg 1 */
	channel->pCAN->canbtr0.byte = CAN_Init->canbtr0.byte; /* bit timing */
	channel->pCAN->canbtr1.byte = CAN_Init->canbtr1.byte; /* filter config */
	channel->pCAN->canidac.byte = CAN_Init->canidac.byte; /* filter acceptance/mask */
	channel->pCAN->canid[0] = CAN_Init->canid[0];
	channel->pCAN->canid[1] = CAN_Init->canid[1];
										
	channel->pCAN->canctl0.byte = 0; /* clear INITRQ */
	while(channel->pCAN->canctl1.bit.initak != 0); /* wait for INITAK to clear */

	channel->pCAN->canctl0.byte = CAN_Init->canctl0.byte; /* control reg 0 */
	channel->pCAN->canrier.byte = CAN_Init->canrier.byte; /* receive interrupts */
	channel->pCAN->cantier.byte = CAN_Init->cantier.byte; /* transmit interrupts */
										
	while(channel->pCAN->canctl0.bit.synch != 1); /* wait for MSCAN to synchronize */

	return;
}


/******************************************************************************
Function Name	:	WriteCANMsg
Engineer		:	r27624	
Date			:	18/03/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
					   len : length
					   data : pointer to source data
Returns		:	 error if box specifies a receive mailbox
Notes			:	 Writes the data and length to the transmit mailbox specified 
******************************************************************************/
tU08 WriteCANMsg(const XGCANstruct *channel, tU08 box, tU08 *len, tU08 *data) 
{	  tU08 *pSrc;
    tU08 i;
                    
    if(box >= (channel->RxBoxSize)) { // check for tx mailbox 
	      do {								          
  		      XGATE.xgsem.word = SETCANSEM;  // lock semaphore 
  	    } 
  	    while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	

		 	  channel->pLength[box] = *len;  // copy length 
  	    pSrc = channel->pBuffer[box];  // source data pointer
										
	      for(i = 0; i < *len; i++) {    // copy data 
            *pSrc++ = *data++;
  	    }
										
	      XGATE.xgsem.word = CLRCANSEM;  // unlock semaphore 
	  
	      return(CAN_ERR_OK);
    }
    else {
        return(CAN_ERR);
    }
}

/******************************************************************************
Function Name	:	SendCANMsg
Engineer		:	r27624	
Date			:	18/03/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
Returns			:	error if box specifies a receive mailbox
Notes			:	Queues a transmit mailbox for transmission. The mailbox data is 
            subsequently loaded into the next available MSCAN buffer by 
            XGATE_CAN_Transmit
******************************************************************************/
tU08 SendCANMsg(const XGCANstruct *channel, tU08 box) 
{
    if(box >= (channel->RxBoxSize)) { // check for tx mailbox 
        do {	
  		      XGATE.xgsem.word = SETCANSEM; // lock semaphore
  	    } 
  	    while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
										
  	    box -= channel->RxBoxSize;  // sub Tx box offset
  	    *(channel->pTxStatus) |= (TXSTATUSMASK<<box); // set Tx status bit 
										
  	    channel->pCAN->cantier.byte = TXE2|TXE1|TXE0;  // enable Tx interrupts 
				
  	    XGATE.xgsem.word = CLRCANSEM; // unlock semaphore 
  	
  	    return(CAN_ERR_OK);
    }
    else {
        return(CAN_ERR);
    }
}

/******************************************************************************
Function Name	:	ReadCANMsg
Engineer		:	r27624	
Date			:	18/03/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
					   len : pointer to length
					   data : pointer to destination data
Returns		:	 none
Notes			:	 reads the data and length from the specified receive or transmit 
             mailbox. Clears the corresponding RxStatus bit for receive mailboxes.
******************************************************************************/
void ReadCANMsg(const XGCANstruct *channel, tU08 box, tU08 *len, tU08 *data) 
{   tU08 i;

	  do {
		    XGATE.xgsem.word = SETCANSEM;   // lock semaphore 
	  } 
	  while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
										
	  *len = channel->pLength[box];       // copy length 
	  for(i=0; i<*len; i++) {
		    *data++ = channel->pBuffer[box][i];  	// copy data 
	  }

	  if(box < (channel->RxBoxSize)) {    // receive mailbox? 
		    *(channel->pRxStatus) &= ~(RXSTATUSMASK<<box);	// clear RxStatus bit 
	  }
										
	  XGATE.xgsem.word = CLRCANSEM;	      // unlock semaphore 
}

/******************************************************************************
Function Name	:	ReadCANMsgId
Engineer		:	r27624	
Date			:	6/04/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
					   id : pointer to identifier
Returns		:	 none
Notes			:	 reads the identifier from the specified receive or transmit 
             mailbox, shifts it to restore to 11-bit value. 
******************************************************************************/
void ReadCANMsgId(const XGCANstruct *channel, tU08 box, tU16 *id) 
{
    do {	
		    XGATE.xgsem.word = SETCANSEM;    // lock semaphore 
	  } 
	  while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
										
	  *id = (channel->pID[box]) >> 5;     // shift identifier and write 
										
	  XGATE.xgsem.word = CLRCANSEM;	 // unlock semaphore 
}

/******************************************************************************
Function Name	:	WriteCANMsgId
Engineer		:	r27624	
Date			:	6/04/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
					   id : pointer to identifier
Returns		:	 error if box specifies a receive mailbox
Notes			:	 writes the shifted identifier to the specified transmit mailbox 
******************************************************************************/
tU08 WriteCANMsgId(const XGCANstruct *channel, tU08 box, tU16 *id) 
{										
    if(box >= (channel->RxBoxSize)) { // check for tx mailbox 
        do {
		        XGATE.xgsem.word = SETCANSEM;  // lock semaphore 
	      } 
	      while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
										
	      channel->pID[box] = CAN_SID(*id);  // shift identifier and write 
										
	      XGATE.xgsem.word = CLRCANSEM;	 // unlock semaphore 
	  
	      return(CAN_ERR_OK);
    }
    else {
        return(CAN_ERR);
    }
}

/******************************************************************************
Function Name	:	FindNewCANMsg
Engineer		:	r27624	
Date			:	24/03/2004
Parameters : channel : pointer to channel identifier structure
Returns		 : mailbox number, or NONEWCANMSG if no new messages.
Notes			 : searches RxStatus_CANx starting at the highest order bit, 
             to find the first set bit indicating a new, unread, message
******************************************************************************/
tU08 FindNewCANMsg(const XGCANstruct *channel) 
{   tS08 box;
	  tU16 rxStatus;

	  do {									
		    XGATE.xgsem.word = SETCANSEM;   // lock semaphore 
	  } 
	  while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
										
	  rxStatus = *(channel->pRxStatus);   // read RxStatus 
										
	  XGATE.xgsem.word = CLRCANSEM;	      // unlock semaphore 
	
	  for(box = (channel->RxBoxSize - 1); box >= 0; box--) { 
        if((rxStatus & (RXSTATUSMASK<<box)) != 0) {	// RxStatus bit set? 							
			      break;  // new message found 
		    }
	  }

	  if(box >= 0) {									
		    return(box);           // new message box #
	  }
	  else {									
		    return(NONEWCANMSG);   // no new messages 
	  }
}


/******************************************************************************
Function Name	:	CheckCANTxStatus
Engineer		:	r54430	
Date			:	25/03/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
Returns		:	mailbox status
Notes			:	status = 1 if the transmit mailbox is queued for transmission and 
            awaiting transfer to MSCAN transmit buffer. Status = 0 otherwise 
******************************************************************************/
tU08 CheckCANTxStatus(const XGCANstruct *channel, tU08 box) 
{	  tU08 status;

	  do {									// lock semaphore 
        XGATE.xgsem.word = SETCANSEM;
	  } 
	  while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	

    box -= channel->RxBoxSize;  // sub Tx box offset 
											
	  status = *(channel->pTxStatus) & (TXSTATUSMASK<<box); // read Tx status bit 
		
	  XGATE.xgsem.word = CLRCANSEM;  // unlock semaphore 

    return(status);
}

/******************************************************************************
Function Name	:	CheckCANRxStatus
Engineer		:	r27624	
Date			:	29/03/2004
Parameters : channel : pointer to channel identifier structure
             box : mailbox number
Returns		:	 mailbox status
Notes			:	 status = 1 if the receive mailbox contains a new message which has 
             not been read by ReadCANMsg. Status = 0 if the mailbox has not 
             received any new CAN message since the mailbox was last read.
******************************************************************************/
tU08 CheckCANRxStatus(const XGCANstruct *channel, tU08 box) 
{   tU08 status;

    do	{									
		    XGATE.xgsem.word = SETCANSEM; // lock semaphore 
	  } 
	  while(!(XGATE.xgsem.byte.xgsemr & CANSEM));	
		
	  status = *(channel->pRxStatus) & (RXSTATUSMASK<<box);  // read Rx status bit 
										
	  XGATE.xgsem.word = CLRCANSEM;     // unlock semaphore 

  	return(status);
}


