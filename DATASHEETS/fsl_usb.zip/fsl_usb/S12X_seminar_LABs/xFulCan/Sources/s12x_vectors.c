/******************************************************************************
									Copyright (c) Freescale Semiconductor 2005
File Name		 :	$RCSfile: s12x_vectors.c,v $

Engineer		 :	$Author: ttz778 $

Location		 :	EKB

Date Created	 :	08/10/2003

Current Revision :	$Revision: 1.2 $

Notes            :  

******************************************************************************/

/************************* Include Files *************************************/
#ifdef __MWERKS__
#include <hidef.h>
#include <start12.h>
#endif
#include "per_XDx512_L15Y.h"
/************************* typedefs ******************************************/
#ifdef __MWERKS__
typedef void (*near tIsrFunc)(void);
#endif 

/************************* #Defines ******************************************/
#ifdef __MWERKS__
#define ReservedISR (tIsrFunc)0xFFFF
#else
#define ReservedISR (void*)0xFFFF
#endif

/************************* Function Prototypes *******************************/
#ifndef __MWERKS__
@interrupt @near void _stext(void);	/* startup routine */
#endif

/************************* Functions *****************************************/
#ifdef __MWERKS__
#pragma CODE_SEG __NEAR_SEG NON_BANKED 
#endif
/******************************************************************************
Function Name	:	UnimplementedISR
Engineer		:	r27624	
Date			:	06/05/2003
Parameters		:	NONE
Returns			:	NONE
Notes			:	Trap for unused interrupt vectors in special modes only. 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
UnimplementedISR(void) 
{
   /* Unimplemented ISRs trap.*/
   _asm("BGND");
}


/******************************************************************************
Function Name	:	SpuriousISR
Engineer		:	r27624	
Date			:	06/05/2003
Parameters		:	NONE
Returns			:	NONE
Notes			:	Trap for spurious interrupt vector in special modes only. 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
SpuriousISR(void) 
{
   /* Spurious ISR trap.*/
   _asm("BGND");
}

/******************************************************************************
Function Name	:	XGATEErrorISR
Engineer		:	r27624	
Date			:	06/05/2003
Parameters		:	NONE
Returns			:	NONE
Notes			:	Trap for spurious interrupt vector in special modes only. 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
XGATEErrorISR(void) 
{
   /* XGATE Error ISR trap.*/
   _asm("BGND");
}

/******************************************************************************
Function Name	:	CAN0_RxNotificationISR
Engineer		:	r27624	
Date			:	03/05/2004
Parameters		:	NONE
Returns			:	NONE
Notes			:	Notification of message received on CAN0 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
CAN0_RxNotificationISR(void) 
{
  /* insert your code here */
  
                          /* clear XGATE channel interrupt flag */
 	XGATE.xgif_50 = BIT9;
}

/******************************************************************************
Function Name	:	CAN1_RxNotificationISR
Engineer		:	r27624	
Date			:	03/05/2004
Parameters		:	NONE
Returns			:	NONE
Notes			:	Notification of message received on CAN1 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
CAN1_RxNotificationISR(void) 
{
  /* insert your code here */
  
                          /* clear XGATE channel interrupt flag */
 	XGATE.xgif_50 = BIT5;
}

/******************************************************************************
Function Name	:	CAN2_RxNotificationISR
Engineer		:	r27624	
Date			:	03/05/2004
Parameters		:	NONE
Returns			:	NONE
Notes			:	Notification of message received on CAN2 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
CAN2_RxNotificationISR(void) 
{
  /* insert your code here */
  
                          /* clear XGATE channel interrupt flag */
 	XGATE.xgif_50 = BIT1;
}

/******************************************************************************
Function Name	:	CAN3_RxNotificationISR
Engineer		:	r27624	
Date			:	03/05/2004
Parameters		:	NONE
Returns			:	NONE
Notes			:	Notification of message received on CAN3 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
CAN3_RxNotificationISR(void) 
{
  /* insert your code here */
  
                          /* clear XGATE channel interrupt flag */
	XGATE.xgif_40 = BITD;
}

/******************************************************************************
Function Name	:	CAN4_RxNotificationISR
Engineer		:	r27624	
Date			:	03/05/2004
Parameters		:	NONE
Returns			:	NONE
Notes			:	Notification of message received on CAN4 
******************************************************************************/
#ifdef __MWERKS__
#pragma TRAP_PROC 
#else
static @interrupt @near
#endif
void 
CAN4_RxNotificationISR(void) 
{
  /* insert your code here */
  
                          /* clear XGATE channel interrupt flag */
	XGATE.xgif_40 = BIT9;
}

/************************* Global Variables **********************************/
#ifdef __MWERKS__
#pragma DATA_SEG DEFAULT
#else
#pragma section const {vector}
#endif

/*****************************************************************************
ResetVectorTable
Interrupt vector table for S12XDP512 
This is the default CPU interrupt vector table at reset: IVBR = $FF
Other vector tables can be created and used by changing IVBR
*****************************************************************************/
#ifdef __MWERKS__
const tIsrFunc ResetVectorTable[] @0xFF10 =
#else
@interrupt @near void (* const ResetVectorTable[])(void) = 
#endif
   {                                      
        SpuriousISR,                      /* 0xFF10 Spurious Interrupt */
        ReservedISR,                      /* 0xFF12 Reserved */
        ReservedISR,                      /* 0xFF14 Reserved */
        ReservedISR,                      /* 0xFF16 Reserved */
        ReservedISR,                      /* 0xFF18 Reserved */
        ReservedISR,                      /* 0xFF1A Reserved */
        ReservedISR,                      /* 0xFF1C Reserved */
        ReservedISR,                      /* 0xFF1E Reserved */
        ReservedISR,                      /* 0xFF20 Reserved */
        ReservedISR,                      /* 0xFF22 Reserved */
        ReservedISR,                      /* 0xFF24 Reserved */
        ReservedISR,                      /* 0xFF26 Reserved */
        ReservedISR,                      /* 0xFF28 Reserved */
        ReservedISR,                      /* 0xFF2A Reserved */
        ReservedISR,                      /* 0xFF2C Reserved */
        ReservedISR,                      /* 0xFF2E Reserved */
        ReservedISR,                      /* 0xFF30 Reserved */
        ReservedISR,                      /* 0xFF32 Reserved */
        ReservedISR,                      /* 0xFF34 Reserved */
        ReservedISR,                      /* 0xFF36 Reserved */
        ReservedISR,                      /* 0xFF38 Reserved */
        ReservedISR,                      /* 0xFF3A Reserved */
        ReservedISR,                      /* 0xFF3C Reserved */
        ReservedISR,                      /* 0xFF3E Reserved */
        ReservedISR,                      /* 0xFF40 Reserved */
        ReservedISR,                      /* 0xFF42 Reserved */
        ReservedISR,                      /* 0xFF44 Reserved */
        ReservedISR,                      /* 0xFF46 Reserved */
        ReservedISR,                      /* 0xFF48 Reserved */
        ReservedISR,                      /* 0xFF4A Reserved */
        ReservedISR,                      /* 0xFF4C Reserved */
        ReservedISR,                      /* 0xFF4E Reserved */
        ReservedISR,                      /* 0xFF50 Reserved */
        ReservedISR,                      /* 0xFF52 Reserved */
        ReservedISR,                      /* 0xFF54 Reserved */
        ReservedISR,                      /* 0xFF56 Reserved */
        ReservedISR,                      /* 0xFF58 Reserved */
        ReservedISR,                      /* 0xFF5A Reserved */
        ReservedISR,                      /* 0xFF5C Reserved */
        ReservedISR,                      /* 0xFF5E Reserved */
        UnimplementedISR,                 /* 0xFF60 XSRAM20K Access Violation */
        XGATEErrorISR,                    /* 0xFF62 XGATE Software Error */
        UnimplementedISR,                 /* 0xFF64 XGATE Software Trigger 7 */
        UnimplementedISR,                 /* 0xFF66 XGATE Software Trigger 6 */
        UnimplementedISR,                 /* 0xFF68 XGATE Software Trigger 5 */
        UnimplementedISR,                 /* 0xFF6A XGATE Software Trigger 4 */
        UnimplementedISR,                 /* 0xFF6C XGATE Software Trigger 3 */
        UnimplementedISR,                 /* 0xFF6E XGATE Software Trigger 2 */
        UnimplementedISR,                 /* 0xFF70 XGATE Software Trigger 1 */
        UnimplementedISR,                 /* 0xFF72 XGATE Software Trigger 0 */
        UnimplementedISR,                 /* 0xFF74 Periodic Interrupt Timer */
        UnimplementedISR,                 /* 0xFF76 Periodic Interrupt Timer */
        UnimplementedISR,                 /* 0xFF78 Periodic Interrupt Timer */
        UnimplementedISR,                 /* 0xFF7A Periodic Interrupt Timer */
        UnimplementedISR,                 /* 0xFF7C Reserved */
        UnimplementedISR,                 /* 0xFF7E API Autonomous Periodical Interrupt */
        UnimplementedISR,                 /* 0xFF80 LVI Low Voltage Interrupt */
        UnimplementedISR,                 /* 0xFF82 IIC1 */
        UnimplementedISR,                 /* 0xFF84 SCI5 */
        UnimplementedISR,                 /* 0xFF86 SCI4 */
        UnimplementedISR,                 /* 0xFF88 SCI3 */
        UnimplementedISR,                 /* 0xFF8A SCI2 */
        UnimplementedISR,                 /* 0xFF8C PWM Emergency Shutdown */
        UnimplementedISR,                 /* 0xFF8E Port P Interrupt */
        UnimplementedISR,                 /* 0xFF90 MSCAN 4 transmit */
        CAN4_RxNotificationISR,           /* 0xFF92 MSCAN 4 receive */
        UnimplementedISR,                 /* 0xFF94 MSCAN 4 errors */
        UnimplementedISR,                 /* 0xFF96 MSCAN 4 wake-up */
        UnimplementedISR,                 /* 0xFF98 MSCAN 3 transmit */
        CAN3_RxNotificationISR,           /* 0xFF9A MSCAN 3 receive */
        UnimplementedISR,                 /* 0xFF9C MSCAN 3 errors */
        UnimplementedISR,                 /* 0xFF9E MSCAN 3 wake-up */
        UnimplementedISR,                 /* 0xFFA0 MSCAN 2 transmit */
        CAN2_RxNotificationISR,           /* 0xFFA2 MSCAN 2 receive */
        UnimplementedISR,                 /* 0xFFA4 MSCAN 2 errors */
        UnimplementedISR,                 /* 0xFFA6 MSCAN 2 wake-up */
        UnimplementedISR,                 /* 0xFFA8 MSCAN 1 transmit */
        CAN1_RxNotificationISR,           /* 0xFFAA MSCAN 1 receive */
        UnimplementedISR,                 /* 0xFFAC MSCAN 1 errors */
        UnimplementedISR,                 /* 0xFFAE MSCAN 1 wake-up */
        UnimplementedISR,                 /* 0xFFB0 MSCAN 0 transmit */
        CAN0_RxNotificationISR,           /* 0xFFB2 MSCAN 0 receive */
        UnimplementedISR,                 /* 0xFFB4 MSCAN 0 errors */
        UnimplementedISR,                 /* 0xFFB6 MSCAN 0 wake-up */
        UnimplementedISR,                 /* 0xFFB8 Flash */
        UnimplementedISR,                 /* 0xFFBA EEPROM */
        UnimplementedISR,                 /* 0xFFBC SPI2 */
        UnimplementedISR,                 /* 0xFFBE SPI1 */
        UnimplementedISR,                 /* 0xFFC0 IIC0 */
        UnimplementedISR,                 /* 0xFFC2 Reserved */
        UnimplementedISR,                 /* 0xFFC4 CRG Self Clock Mode */
        UnimplementedISR,                 /* 0xFFC6 CRG PLL lock */
        UnimplementedISR,                 /* 0xFFC8 Pulse accumulator B overflow */
        UnimplementedISR,                 /* 0xFFCA Modulus Down Counter Underflow */
        UnimplementedISR,                 /* 0xFFCC Port H */
        UnimplementedISR,                 /* 0xFFCE Port J */
        UnimplementedISR,                 /* 0xFFD0 ATD1 */
        UnimplementedISR,                 /* 0xFFD2 ATD0 */
        UnimplementedISR,                 /* 0xFFD4 SCI1 */
        UnimplementedISR,                 /* 0xFFD6 SCI0 */
        UnimplementedISR,                 /* 0xFFD8 SPI0 */
        UnimplementedISR,                 /* 0xFFDA Pulse accumulator input edge */
        UnimplementedISR,                 /* 0xFFDC Pulse accumulator A overflow */
        UnimplementedISR,                 /* 0xFFDE Enhanced Capture Timer overflow  */
        UnimplementedISR,                 /* 0xFFE0 Enhanced Capture Timer channel 7 */
        UnimplementedISR,                 /* 0xFFE2 Enhanced Capture Timer channel 6 */
        UnimplementedISR,                 /* 0xFFE4 Enhanced Capture Timer channel 5 */
        UnimplementedISR,                 /* 0xFFE6 Enhanced Capture Timer channel 4 */
        UnimplementedISR,                 /* 0xFFE8 Enhanced Capture Timer channel 3 */
        UnimplementedISR,                 /* 0xFFEA Enhanced Capture Timer channel 2 */
        UnimplementedISR,                 /* 0xFFEC Enhanced Capture Timer channel 1 */
        UnimplementedISR,                 /* 0xFFEE Enhanced Capture Timer channel 0 */
        UnimplementedISR,                 /* 0xFFF0 Real Time Interrupt */
        UnimplementedISR,                 /* 0xFFF2 IRQ */
        UnimplementedISR,                 /* 0xFFF4 XIRQ */
        UnimplementedISR,                 /* 0xFFF6 SWI */
        UnimplementedISR,                 /* 0xFFF8 Unimplemented instruction trap */
        UnimplementedISR,                 /* 0xFFFA COP failure reset */
        UnimplementedISR,                 /* 0xFFFC Clock monitor fail reset */
#ifdef __MWERKS__
        _Startup                          /* 0xFFFE Reset vector */
#else
        _stext                            /* 0xFFFE Reset vector */
#endif
   };
   
#ifndef __MWERKS__
#pragma section const {}
#endif
   
   
