#include <hidef.h>      
#include <MC9S12XEP100.h>     
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#include <string.h>
#include "xgate.h"

// this variable definition is to demonstrate how to share data between XGATE and S12X 
#pragma DATA_SEG SHARED_DATA
volatile int shared_counter; 
#pragma DATA_SEG DEFAULT


#define ROUTE_INTERRUPT(vec_adr, cfdata)                \
  INT_CFADDR= (vec_adr) & 0xF0;                         \
  INT_CFDATA_ARR[((vec_adr) & 0x0F) >> 1]= (cfdata)


#define SOFTWARETRIGGER0_VEC  0x72  /* vector address= 2 * channel id */

#define SOFTWARETRIGGER1_VEC  0x70  //XGATE soft trigger 1, intended to be used for CPU trigger CPU
#define SOFTWARETRIGGER2_VEC  0x6E  //XGATE soft trigger 2, intended to be used for CPU trigger XGATE
#define SOFTWARETRIGGER3_VEC  0x6C  //XGATE soft trigger 3, intended to be used for XGATE trigger CPU
#define SOFTWARETRIGGER4_VEC  0x6A  //XGATE soft trigger 3, intended to be used for XGATE trigger XGATE



static void SetupXGATE(void) {
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xFBC1; /* XGE | XGFRZ | XGIE */

//  XGMCTL= 0xFBE1; /* XGE | XGIE */  

}


void Delay_s12(unsigned int duration) 
{  int count,idx;

   for (count=0;count<duration;count++) {
       for (idx=0;idx<5000;idx++) {
           ;
       }
   }
}



void main(void) {

  SetupXGATE();

// step1: Config PortA[3..0] as output, P[1..0] as input
  DDRA  = 0x0F;


  ROUTE_INTERRUPT(SOFTWARETRIGGER1_VEC, 0x01);  // trigger CPU 
  ROUTE_INTERRUPT(SOFTWARETRIGGER2_VEC, 0x81);  // trigger XGATE
  ROUTE_INTERRUPT(SOFTWARETRIGGER3_VEC, 0x01);  // trigger CPU   
  ROUTE_INTERRUPT(SOFTWARETRIGGER4_VEC, 0x81);  // trigger XGATE

  EnableInterrupts;

  XGSWT= 0x0202;   // invoke software trigger 1 handler
  
  for(;;) {
  
//    XGSWT= 0x0202;   // invoke software trigger 1 handler
//    Delay_s12(50);  

  }

}











// VECTOR ADDRESS 0xFF70 XgSwTrigger1_Handler
// VECTOR ADDRESS 0xFF6C XgSwTrigger3_Handler





#pragma CODE_SEG __NEAR_SEG NON_BANKED 
interrupt void XgSwTrigger1_Handler() 
{
    PORTA  = 0x01;
    Delay_s12(30);
    
    XGSWT  = 0x0200;  // clear software trigger 1 flag
   
   
    XGSWT  = 0x0404;  // invoke software trigger 2 handler   
}



interrupt void XgSwTrigger3_Handler() 
{
    PORTA  = 0x04;
    Delay_s12(30);
    
    XGSWT  = 0x0800;  // clear software trigger 3 flag
   
   
    XGSWT  = 0x1010;  // invoke software trigger 4 handler   
}