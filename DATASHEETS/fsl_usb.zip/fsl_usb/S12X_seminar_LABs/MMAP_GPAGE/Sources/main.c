#include <hidef.h>            /* common defines and macros */
#include <MC9S12XEP100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#pragma CONST_SEG  __GPAGE_SEG  MY_BIG_CONST_DATA
extern const unsigned long myBigConstTable[];  //this is an object bigger than 16K defined in myConstData.c
#pragma CONST_SEG DEFAULT

  
volatile unsigned long temp;  
unsigned long * __far myGlobalPointer;
  
void main(void) {
  
//Accessing our big object directly  
    temp=myBigConstTable[0];
    temp=myBigConstTable[1];
    temp=myBigConstTable[2];
    temp=myBigConstTable[3];              

    temp=myBigConstTable[1026];
    temp=myBigConstTable[1027];
    temp=myBigConstTable[1028];
    temp=myBigConstTable[1029];

    temp=myBigConstTable[4095];
    temp=myBigConstTable[4096];
    temp=myBigConstTable[4097];

    temp=myBigConstTable[4108];
    temp=myBigConstTable[4109];
    temp=myBigConstTable[4111];

  
//Accessing it through a pointer: 
    myGlobalPointer = (unsigned long * __far)&myBigConstTable[0]; 
    temp=*myGlobalPointer;
  
    myGlobalPointer = (unsigned long * __far)&myBigConstTable[1026]; 
    temp=*myGlobalPointer;           

    myGlobalPointer = (unsigned long * __far)&myBigConstTable[4096]; 
    temp=*myGlobalPointer;           

    myGlobalPointer = (unsigned long * __far)&myBigConstTable[4111]; 
    temp=*myGlobalPointer;  

  
    for(;;) { } 
}







