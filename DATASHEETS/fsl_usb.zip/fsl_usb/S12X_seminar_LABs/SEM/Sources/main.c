#include <hidef.h>      /* common defines and macros */
#include <MC9S12XEP100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#include <string.h>
#include "xgate.h"

/* this variable definition is to demonstrate how to share data between XGATE and S12X */
#pragma DATA_SEG SHARED_DATA
volatile int shared_counter; /* volatile because both cores are accessing it. */
#pragma DATA_SEG DEFAULT


#define ROUTE_INTERRUPT(vec_adr, cfdata)                \
  INT_CFADDR= (vec_adr) & 0xF0;                         \
  INT_CFDATA_ARR[((vec_adr) & 0x0F) >> 1]= (cfdata)

#define SOFTWARETRIGGER0_VEC  0x72 /* vector address= 2 * channel id */



static void SetupXGATE(void) {
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* switch software trigger 0 interrupt to XGATE */
  ROUTE_INTERRUPT(SOFTWARETRIGGER0_VEC, 0x81); /* RQST=1 and PRIO=1 */

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xFBC1; /* XGE | XGFRZ | XGIE */

  /* force execution of software trigger 0 handler */
  XGSWT= 0x0101;
}



void Delay_s12(unsigned int duration) 
{  int count,idx;

   for (count=0;count<duration;count++) {
       for (idx=0;idx<5000;idx++) {
           ;
       }
   }
}

void main(void) {
/* put your own code here */


// step1: Config PortA[3..0] as output, P[1..0] as input
    DDRA  = 0x0F;
    DDRP &= 0xFC;


    SetupXGATE();
    EnableInterrupts;


    for(;;) {
        if ((PTP&0x02)==0x00) {
 
do {
  XGSEM = 0x0101;                // Try to grab semaphore 0 by writing both bits
} while (!(XGSEM_XGSEM&0x0001)); // Check if semaphore was locked


            PORTA  = 0x09; 
            Delay_s12(30);
            PORTA  = 0x06;             
            Delay_s12(30);   
            PORTA  = 0x09; 
            Delay_s12(30);
            PORTA  = 0x06;             
            Delay_s12(30);   
            PORTA  = 0x09; 
            Delay_s12(30);
            PORTA  = 0x06;             
            Delay_s12(30);   
            PORTA  = 0x09; 
            Delay_s12(30);
            PORTA  = 0x06;             
            Delay_s12(30);
            PORTA  = 0x00;                            

XGSEM = 0x0100;                  // Clear semaphore 0 by writing mask=1 and flag=0

        }    
    }

}














































/*

do {
  XGSEM = 0x0101;                // Try to grab semaphore 0 by writing both bits
} while (!(XGSEM_XGSEM&0x0001)); // Check if semaphore was locked

....


XGSEM = 0x0100;                  // Clear semaphore 0 by writing mask=1 and flag=0
 
*/