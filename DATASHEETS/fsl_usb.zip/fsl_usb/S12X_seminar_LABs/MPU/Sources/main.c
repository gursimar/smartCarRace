/******************************************************************************
													            Copyright (c) Freescale 2006
File Name    : $RCSfile: main.c,v $

Current Revision :	$Revision: 1.1 $

PURPOSE: Example 4: Using Semaphores
                                                                          
                                                                       
DESCRIPTION:  In this example you will use semaphores to control access to
              a single resource.
                          
                                                                                                                   
UPDATE HISTORY                                                            
REV  AUTHOR    DATE        DESCRIPTION OF CHANGE                          
---  ------    --------    ---------------------                          
1.0                        - initial coding
1.1  b06321    13/12/06    - ported to S12XE

     *******************************************************************
     * File created by: Freescale East Kilbride MCD Applications Group *
     *******************************************************************

******************************************************************************/
#include <hidef.h>            /* common defines and macros */
#include <mc9s12xep100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#include <string.h>
#include "xgate.h"

#define CPU_Request 0x01;
#define XGate_Request 0x81;

#pragma DATA_SEG PAGED_RAM
volatile char CPU_violate;

#pragma DATA_SEG DEFAULT_RAM
volatile char count;
volatile long shift;

/******************************************************************************
Function Name  : SetupXGATE
Engineer       : r32151	
Date           : 01/03/2005
Parameters     : NONE
Returns        : NONE
Notes          : initialize the XGATE vector block
******************************************************************************/
static void SetupXGATE(void) {
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xE1C1; /* XGE | XGFRZ | XGIE */
  //XGMCTL= 0xC1C1;
  /* NB - Bug in Debugger means XGDBG needs to be cleared */
}

/******************************************************************************
Function Name  : main
Engineer       : r32151	
Date           : 01/03/2005
Parameters     : NONE
Returns        : NONE
Notes          : main routine called by Startup.c, Sets up required ports, PIT and ADC.
                 Allocates events between CPU and XGATE.
                 Triggers PIT if ADC value changes by > 5
******************************************************************************/
void main(void) {
// Protect Flash beyond CPU code 
// i.e.  CPU address >= 0xFE80C0 (Global 0x7F80C0)
// Care has to be taken as CPU will do pre-fetch of program code beyond current instruction

// find main in map file:
//   main     FE800D     0x74     116       2   .text
//   thus: main in globle address: 0x7F800D to 0x7F8081


  MPUSEL   = 0x81;    // SVSEN, Descriptor 1 


  MPUDESC0 = 0x8F;    // Protect CPU - has to be supervisor
  MPUDESC1 = 0xF0;    // LOW_ADDR = 0x7F8080 >> 3 = 0xFF010
  MPUDESC2 = 0x20;    // => 0x00


/*
  MPUDESC0 = 0x8F;    // Protect CPU - has to be supervisor
  MPUDESC1 = 0xF0;    // LOW_ADDR = 0x7F8080 >> 3 = 0xFF010
  MPUDESC2 = 0x11;    // => 0x00
*/

  
  MPUDESC3 = 0x4F;    // NEX:  0x4F (read, write) => 0x8F  (read,exe)
  MPUDESC4 = 0xF7;    // HIGH_ADDR = 0x7FBFFF >> 3 = 0xFF7FF (top of 16K flash page FE)
  MPUDESC5 = 0xFF;    //


  SetupXGATE();

  count = 0x0000;
  
/* Set up Port A */
  PORTA = 0x00;
  DDRA  = 0x0F;
  PUCR  = 0x42;
  
/* Set up Port A */
  PORTB = 0x00;
  DDRB  = 0x00;

/* Enable PIT channels 1 */
  PITCFLMT = 0x80;    /* Enable PIT */
  PITCE    = 0x02;    /* Enable channel 1 */ 
  PITMUX   = 0x00;    /* Use microtimer 0 for all channels */
  PITMTLD0 = 200;     /* Microtimer count of 200 */
  PITLD1   = 5000;    /* Channel 1 counter of 5000 */
  
  /* Allocate events to CPU or XGate */
  INT_CFADDR = 0x70;  /* Set interrupt control page to PIT channels */
  INT_CFDATA4 = XGate_Request;  /* Send interrupt to XGate (level 1) */

  //IRQ pin is floating on DEMO boards
  INT_CFADDR = 0xF0;  /* Set interrupt control page to IRQ channels */
  INT_CFDATA1 = 0;    /* Block IRQ from causing interrupt (dynamic alternative to IRQCR bit) */

  // NOPs used to align end of CPU code to 8 byte boundary.
  asm (nop);
  asm (nop);
  asm (nop);
  asm (nop);
  
  // Have to enable interrupts after MPU set or will get XGate ISR before MPU configured
  // TASK 2 - uncomment following line
  PITINTE  = 0x02;    /* Enable interrupts on channels 0 & 1 */  
  
  EnableInterrupts;
  
  for(;;) {
    CPU_violate = 0x55;
  } /* wait forever */
  /* please make sure that you never leave this function */
}

#pragma CODE_SEG __NEAR_SEG NON_BANKED 
/*****************************************************************************/
/********* INTERRUPT SERVICE ROUTINES ***********/
/*****************************************************************************/
interrupt void XG_SW_ERROR_ISR(void)
{
  // XGate has caused access violation - light LED3
  // Clear XG SW Error interrupt
  XGMCTL  = 0x0202; 
  PORTA  |= 0x04;
}




unsigned char MPU_FLAG_REGISTER;
unsigned long MPU_ADDRESS_STATUS_REGISTER;
interrupt void MPU_ISR(void)
{
// read the violation status registers
  MPU_FLAG_REGISTER = MPUFLG;
  MPU_ADDRESS_STATUS_REGISTER =  (((unsigned long)MPUASTAT0) <<16) |
                                 (((unsigned long)MPUASTAT1) <<8 ) |  
                                 (((unsigned long)MPUASTAT2)     ); 

// Clear MPU AEF
  MPUFLG  = 0x80;
// CPU has caused access violation - light LED4
  PORTA  |= 0x08;
}



