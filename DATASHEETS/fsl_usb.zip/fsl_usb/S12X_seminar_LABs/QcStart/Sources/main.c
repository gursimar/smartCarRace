#include <hidef.h>      /* common defines and macros */
#include <MC9S12XEP100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"

#include "main_asm.h" /* interface to the assembly module */

#include <string.h>
#include "xgate.h"

/* this variable definition is to demonstrate how to share data between XGATE and S12X */
#pragma DATA_SEG SHARED_DATA
volatile int shared_counter; /* volatile because both cores are accessing it. */
#pragma DATA_SEG DEFAULT


#define ROUTE_INTERRUPT(vec_adr, cfdata)                \
  INT_CFADDR= (vec_adr) & 0xF0;                         \
  INT_CFDATA_ARR[((vec_adr) & 0x0F) >> 1]= (cfdata)

#define SOFTWARETRIGGER0_VEC  0x72 /* vector address= 2 * channel id */
static void SetupXGATE(void) {
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* switch software trigger 0 interrupt to XGATE */
  ROUTE_INTERRUPT(SOFTWARETRIGGER0_VEC, 0x81); /* RQST=1 and PRIO=1 */

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xFBC1; /* XGE | XGFRZ | XGIE */

  /* force execution of software trigger 0 handler */
  XGSWT= 0x0101;
}





void InitGPIOA(void);
void DispLED(unsigned char cnt);
void Delay(unsigned int duration); 



void main(void) {
/* put your own code here */
  unsigned char digit=0;

  SetupXGATE();
//  EnableInterrupts;
//  asm_main(); /* call the assembly function */

  InitGPIOA();

  for(;;) {
      DispLED(digit++);
      Delay(5);
  } /* wait forever */
  /* please make sure that you never leave this function */
}








void InitGPIOA(void) 
{
// please set Port A[3..0] as output
   DDRA = 0x0F;
}


void DispLED(unsigned char cnt) 
{
   PORTA = cnt&0x0F;
}


void Delay(unsigned int duration) 
{  int count,idx;

   for (count=0;count<duration;count++) {
       for (idx=0;idx<5000;idx++) {
           ;
       }
   }
}



    
  

  