#include <hidef.h>      /* common defines and macros */
#include <MC9S12XEP100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#pragma DATA_SEG __RPAGE_SEG PAGED_RAM
//#pragma DATA_SEG PAGED_RAM
volatile unsigned char pagedRamVariable;



#pragma DATA_SEG DEFAULT

unsigned char * __rptr pointerToVariable;
//unsigned char * pointerToVariable;


void main(void) {
//write a value
  pagedRamVariable=0xBB;
  
  pagedRamVariable=0xCC;
  
//Let's write a value to RPAGE just for fun
  RPAGE=0xF9;

//Initialize pointer to point at address of pagedRamVariable
  pointerToVariable=&pagedRamVariable;
  
//write another value via use of pointer
  *pointerToVariable=0xDD;

  *pointerToVariable=0xEE;  

  for(;;) {} 

}












































/*
#pragma DATA_SEG __RPAGE_SEG PAGED_RAM


unsigned char * __rptr pointerToVariable;


-D__FAR_DATA in compiler
*/









