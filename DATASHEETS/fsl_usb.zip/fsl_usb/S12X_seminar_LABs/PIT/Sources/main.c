#include <hidef.h>      /* common defines and macros */
#include <MC9S12XEP100.h>     /* derivative information */
#pragma LINK_INFO DERIVATIVE "mc9s12xep100"


#include <string.h>
#include "xgate.h"

/* this variable definition is to demonstrate how to share data between XGATE and S12X */
#pragma DATA_SEG SHARED_DATA
volatile int shared_counter; /* volatile because both cores are accessing it. */
#pragma DATA_SEG DEFAULT


#define ROUTE_INTERRUPT(vec_adr, cfdata)                \
  INT_CFADDR= (vec_adr) & 0xF0;                         \
  INT_CFDATA_ARR[((vec_adr) & 0x0F) >> 1]= (cfdata)

#define SOFTWARETRIGGER0_VEC  0x72 /* vector address= 2 * channel id */

// step 6: Config PIT channel 0 interrupt register: define vector number
#define PIT_CH0_VEC           0x7A    

static void SetupXGATE(void) {
  /* initialize the XGATE vector block and
     set the XGVBR register to its start address */
  XGVBR= (unsigned int)(void*__far)(XGATE_VectorTable - XGATE_VECTOR_OFFSET);

  /* switch software trigger 0 interrupt to XGATE */
  ROUTE_INTERRUPT(SOFTWARETRIGGER0_VEC, 0x81); /* RQST=1 and PRIO=1 */
  
// step 6: Config PIT channel 0 interrupt register 
  ROUTE_INTERRUPT(PIT_CH0_VEC, 0x81); // RQST=1: route PIT_ch0 to XGATE; PRIO=1: priority = 1   

  /* enable XGATE mode and interrupts */
  XGMCTL= 0xFBC1; /* XGE | XGFRZ | XGIE */

  /* force execution of software trigger 0 handler */
  XGSWT= 0x0101;
}



void main(void) {
  /* put your own code here */


// step1: Config PortA[3..0] as output
    DDRA = 0x0F;

// step2: Config PIT channel 0 
    PITCFLMT &= 0x7F;          //Disable PIT first
    PITMUX   |= 0x01;          //Ch0 use macro timer 1

    while (PITTF) PITTF=0x0F;  //clear all exist overflow flag
    
    PITMTLD1 = 200-1;          //Macro timer1 load = 200, output->BusClk/200 to 16bit-timer
    PITLD0   = 10000-1;        //Channel0: BusClk/200/10000  1Hz @ 2M

    PITINTE |=0x01;            //enable the PIT channel 0 interrupt    
    PITCE   |=0x01;            //enable the PIT channel 0
        
    PITCFLMT|=0x80;            //enable PIT    

    SetupXGATE();
    EnableInterrupts;




    for(;;) {} /* wait forever */
  /* please make sure that you never leave this function */
}










/*
// step1: config Port A[3..0] as output
   DDRA = 0x0F;

// step2: config PIT channel0 
    PITCFLMT &= 0x7F;          //Disable PIT first
    PITMUX    = 0x0C;          //Ch0/1 use macro timer0, Ch2/3 use macro timer1
                               
    while (PITTF) PITTF=0x0F;  //clear all exist overflow flag
        
    PITMTLD0 =200-1;             //Macro timer0 load = 40, output->Busclk/200 to 16bit-timer
    PITMTLD1 =  4-1;             //Macro timer1 load =  4, output->BusClk/4 to 16bit-timer    
    
    PITLD0   = 2000-1;           //Channel0: BusClk/200/2000  100Hz@40M
    PITLD1   =   40-1;           //Channel1: BusClk/40/200    5K@40M
    PITLD2   = 2000-1;           //Channel1: BusClk/4/2000    5K@40M     
    PITLD3   = 2000-1;           //Channel1: BusClk/4/2000    5K@40M         

    PITINTE =0x07;             //enable the PIT channel 0 interrupt    
    PITCE  = 0x07;             //enable the PIT channel 0/1/2
        
    PITCFLMT|=0x80;  //enable PIT    
}
 
*/